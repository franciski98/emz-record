import Header from './components/Header';
import Hero from './components/Hero';
import FeaturedRelease from './components/FeaturedRelease';
import Actualites from './components/Actualites';
import MediaCenter from './components/MediaCenter';
import Boutique from './components/Boutique';
import Roster from './components/Roster';
import Cagnotte from './components/Cagnotte';
import Studio from './components/Studio';
import ContactDemo from './components/ContactDemo';
import Footer from './components/Footer';

export default function App() {
  return (
    <div className="relative bg-rich-black min-h-screen text-gray-200 overflow-x-hidden font-sans">
      {/* Sticky Premium Header Row */}
      <Header />

      {/* Main Sections */}
      <main>
        <Hero />
        <FeaturedRelease />
        <Actualites />
        <MediaCenter />
        <Boutique />
        <Roster />
        <Cagnotte />
        <Studio />
        <ContactDemo />
      </main>

      {/* Footer minimaliste et centré */}
      <Footer />
    </div>
  );
}
