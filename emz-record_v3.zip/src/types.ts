export interface Artist {
  id: string;
  name: string;
  role: string;
  image: string;
  bio: string;
  streamingLinks: {
    spotify?: string;
    appleMusic?: string;
    youtube?: string;
    instagram?: string;
  };
}

export interface NewsStory {
  id: string;
  title: string;
  summary: string;
  content: string;
  date: string;
  badge: string;
  image: string;
}

export interface StudioService {
  id: string;
  title: string;
  description: string;
}

export interface BoutiqueItem {
  id: string;
  title: string;
  price: string;
  category: string;
  artistCreator: string;
  image: string;
  description: string;
  details: string[];
}

export interface DemoSubmission {
  artistName: string;
  email: string;
  trackTitle: string;
  genre: string;
  demoLink: string;
  message: string;
}


