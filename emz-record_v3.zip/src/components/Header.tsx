import { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import Logo from './Logo';

export default function Header() {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: "Accueil", href: "#accueil" },
    { name: "Sorties d'Or", href: "#releases" },
    { name: "Exclusivités", href: "#media-center" },
    { name: "La Gazette", href: "#news" },
    { name: "Boutique", href: "#boutique" },
    { name: "Roster", href: "#roster" },
    { name: "Mécénat", href: "#mece-cagnotte" },
    { name: "Studio", href: "#studio" },
    { name: "Contact", href: "#contact" }
  ];

  return (
    <header className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
      isScrolled ? 'bg-rich-black/90 backdrop-blur-md border-b border-gold/10 py-4' : 'bg-transparent py-6'
    }`}>
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        {/* Logo with official EMZ claws brand design */}
        <a href="#accueil" className="flex items-center gap-2 group">
          <motion.div 
            whileHover={{ scale: 1.1 }}
            transition={{ type: "spring", stiffness: 400, damping: 10 }}
            className="flex items-center gap-1.5"
          >
            <Logo iconOnly={true} color="gold" showText={false} className="w-10 h-8 text-gold group-hover:scale-105 transition-all" />
            <span className="font-display text-2xl tracking-widest text-[#E8E8E8] group-hover:text-gold transition-colors uppercase pt-1">
              EMZ RECORD
            </span>
          </motion.div>
        </a>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              className="text-sm font-sans tracking-wide text-gray-300 hover:text-gold transition-colors relative after:absolute after:-bottom-1 after:left-0 after:w-0 after:h-[1px] after:bg-gold hover:after:w-full after:transition-all after:duration-300"
            >
              {link.name}
            </a>
          ))}
          <a
            href="#contact"
            className="px-4 py-2 text-xs uppercase tracking-widest border border-gold/40 text-gold hover:bg-gold hover:text-rich-black transition-all duration-300 rounded-sm font-sans"
          >
            Soumettre Démo
          </a>
        </nav>

        {/* Mobile Menu Trigger */}
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="md:hidden text-gray-300 hover:text-gold transition-colors p-2"
          aria-label="Toggle menu"
          id="burger-menu"
        >
          {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Menu Dropdown */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-rich-black/95 backdrop-blur-lg border-b border-gold/15"
          >
            <div className="flex flex-col gap-6 px-6 py-8">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  onClick={() => setIsOpen(false)}
                  className="text-lg font-sans tracking-wider text-gray-300 hover:text-gold transition-colors border-b border-gold/5 pb-2"
                >
                  {link.name}
                </a>
              ))}
              <a
                href="#contact"
                onClick={() => setIsOpen(false)}
                className="w-full text-center px-4 py-3 uppercase tracking-widest border border-gold/60 text-gold hover:bg-gold hover:text-rich-black transition-all duration-300 rounded-sm font-sans text-sm"
              >
                Soumettre une Démo
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
