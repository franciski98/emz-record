import { motion } from 'motion/react';
import { ArrowRight, Volume2 } from 'lucide-react';
import Logo from './Logo';

export default function Hero() {
  return (
    <section 
      id="accueil" 
      className="relative min-h-screen flex items-center justify-center overflow-hidden bg-rich-black pt-20 px-6"
    >
      {/* Background radial glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-gold/5 blur-[120px] rounded-full pointer-events-none" />
      <div className="absolute top-20 right-10 w-[300px] h-[300px] bg-gold/5 blur-[100px] rounded-full pointer-events-none" />

      {/* Decorative Wave Design / Grid Element */}
      <div className="absolute inset-0 opacity-10 bg-[linear-gradient(to_right,#C9A84C_1px,transparent_1px),linear-gradient(to_bottom,#C9A84C_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)] pointer-events-none" />

      <div className="relative z-10 max-w-5xl mx-auto text-center flex flex-col items-center">
        {/* Subtitle Accent */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="flex items-center gap-2 mb-6 px-4 py-1.5 rounded-full border border-gold/20 bg-gold/5 backdrop-blur-sm"
        >
          <Volume2 className="w-4 h-4 text-gold animate-pulse" />
          <span className="text-xs uppercase tracking-widest text-gold font-sans font-medium">
            Maison de Haute Production Musicale
          </span>
        </motion.div>

        {/* Large Iconic Brand Emblem */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 1.2, ease: "easeOut", delay: 0.15 }}
          className="mb-8"
        >
          <Logo color="red" className="drop-shadow-[0_0_30px_rgba(210,20,58,0.25)] hover:scale-105 transition-transform duration-500" />
        </motion.div>

        {/* Main Title with shimmering golden gradient */}
        <motion.h1
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, delay: 0.2 }}
          className="font-display text-7xl sm:text-8xl md:text-9xl tracking-tight leading-none mb-6 group select-none cursor-default"
        >
          <span className="block text-gray-400 text-3xl sm:text-4xl md:text-5xl tracking-[0.3em] font-sans font-light uppercase mb-2">
            L'Expérience Elite par
          </span>
          <span className="gold-gradient-text block relative">
            EMZ RECORD
          </span>
        </motion.h1>

        {/* Editorial Body Text */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="text-gray-400 font-sans font-light text-base md:text-lg max-w-2xl leading-relaxed mb-12"
        >
          Là où l'excellence sonore rencontre la haute couture culturelle africaine. 
          Découvrez des sonorités d'exception taillées pour les scènes internationales 
          par les artistes et producteurs les plus influents du continent.
        </motion.p>

        {/* Action Button are animated */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="flex flex-col sm:flex-row gap-6 items-center"
        >
          <a
            href="#roster"
            className="group relative inline-flex items-center gap-2 px-8 py-4 overflow-hidden rounded-sm bg-rich-black text-white border border-gold/30 hover:border-gold transition-all duration-300 shadow-md gold-glow"
            id="cta-explore-roster"
          >
            {/* Shimmer Border Animation */}
            <span className="absolute inset-0 bg-gradient-to-r from-gold/0 via-gold/20 to-gold/0 -translate-x-full group-hover:translate-x-full transition-transform duration-1000 ease-in-out" />
            
            <span className="font-sans text-sm uppercase tracking-widest text-gold font-semibold">
              Explorez le Roster
            </span>
            <ArrowRight className="w-4 h-4 text-gold group-hover:translate-x-1 transition-transform" />
          </a>

          <a
            href="#releases"
            className="font-sans text-sm uppercase tracking-widest text-gray-400 hover:text-gold transition-colors py-2 border-b border-transparent hover:border-gold/30"
          >
            Dernières Créations
          </a>
        </motion.div>
      </div>

      {/* Elegant visual equalizer footer representation in background */}
      <div className="absolute bottom-0 left-0 w-full flex justify-center items-end h-16 pointer-events-none opacity-20">
        {[20, 45, 30, 60, 25, 50, 80, 40, 35, 70, 50, 90, 65, 40, 20, 60, 45, 30, 75, 55].map((val, i) => (
          <motion.div
            key={i}
            className="w-1 bg-gold mx-0.5 rounded-t-sm"
            animate={{ height: [`${val * 0.3}px`, `${val}px`, `${val * 0.3}px`] }}
            transition={{
              duration: 1 + (i % 3) * 0.4 ,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />
        ))}
      </div>
    </section>
  );
}
