import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShoppingBag, Sparkles, Check, ArrowRight, MessageCircle, X } from 'lucide-react';
import { BOUTIQUE_ITEMS } from '../data';
import { BoutiqueItem } from '../types';

export default function Boutique() {
  const [selectedCategory, setSelectedCategory] = useState<string>('Tous');
  const [activeItem, setActiveItem] = useState<BoutiqueItem | null>(null);

  const categories = ['Tous', 'Accessoires Couture', 'Prêt-à-Porter Haute Couture', "Robes d'Apparat"];

  const filteredItems = selectedCategory === 'Tous'
    ? BOUTIQUE_ITEMS
    : BOUTIQUE_ITEMS.filter(item => item.category === selectedCategory);

  const handleWhatsAppOrder = (item: BoutiqueItem) => {
    const labelNumber = "22672366484"; // Pre-filled secure whatsapp contact line for EMZ Record
    const encodedMessage = encodeURIComponent(
      `Bonjour EMZ RECORD,\n\nJe suis très intéressé par l'article d'artisanat d'art "${item.title}" conçu en exclusivité par ${item.artistCreator}.\n\nEst-il possible d'effectuer une commande personnalisée à mes mesures ? Merci !`
    );
    window.open(`https://wa.me/${labelNumber}?text=${encodedMessage}`, '_blank');
  };

  return (
    <section id="boutique" className="bg-[#0D0D0D] py-24 px-6 border-b border-gold/10 relative overflow-hidden">
      {/* Background Decorative Accents */}
      <div className="absolute top-1/4 left-0 w-96 h-96 bg-gold/5 blur-[120px] rounded-full pointer-events-none" />
      <div className="absolute bottom-1/4 right-0 w-96 h-96 bg-[#9B111E]/5 blur-[120px] rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Section Header */}
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-3 py-1 border border-gold/30 bg-gold/5 rounded-full mb-4"
          >
            <Sparkles className="w-3 h-3 text-gold animate-pulse" />
            <span className="text-[10px] uppercase tracking-[0.3em] text-gold font-mono font-medium">Boutique éphémère d'Artisans</span>
          </motion.div>
          
          <motion.h2
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="font-display text-4xl md:text-5xl lg:text-6xl text-white tracking-wide uppercase mb-4"
          >
            L'Atelier <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#FFEAB5] via-[#C9A84C] to-[#8A6F27]">Prestige</span>
          </motion.h2>
          
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-gray-400 font-sans font-light text-sm md:text-base max-w-2xl mx-auto leading-relaxed"
          >
            Découvrez des pièces uniques de haute couture, des accessoires originaux et des créations précieuses 
            façonnées entièrement à la main par nos artistes phares et maîtres artisans d'art.
          </motion.p>
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap justify-center gap-3 mb-16">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-5 py-2 text-xs uppercase tracking-widest transition-all duration-300 rounded-none border font-mono ${
                selectedCategory === category
                  ? 'bg-gold border-gold text-rich-black font-semibold'
                  : 'bg-transparent border-white/10 text-gray-400 hover:border-gold/40 hover:text-white'
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Catalog Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredItems.map((item, index) => (
            <motion.div
              layout
              key={item.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group border border-gold/10 bg-[#121212]/90 rounded-none overflow-hidden hover:border-gold/30 transition-all duration-500 shadow-xl flex flex-col justify-between"
            >
              {/* Product Visual Container */}
              <div className="relative aspect-[4/5] overflow-hidden bg-black flex items-center justify-center">
                <img
                  src={item.image}
                  alt={item.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 filter brightness-95"
                />
                
                {/* Creator Artist Tag */}
                <div className="absolute top-4 left-4 bg-rich-black/85 border border-gold/30 px-3 py-1.5 backdrop-blur-sm z-10 flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#D2143A] animate-ping" />
                  <span className="text-[10px] tracking-[0.15em] font-mono font-medium text-[#FFEAB5] uppercase">
                    Par {item.artistCreator}
                  </span>
                </div>

                {/* Category Strip */}
                <div className="absolute bottom-4 left-4 bg-gold/90 text-rich-black px-2.5 py-1 text-[9px] tracking-widest uppercase font-mono font-bold">
                  {item.category}
                </div>

                {/* Quick Details Hover Overlay */}
                <div className="absolute inset-0 bg-rich-black/85 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-center p-8 z-20">
                  <h4 className="font-display text-xl text-gold uppercase tracking-wider mb-2">{item.title}</h4>
                  <span className="text-gray-500 text-[10px] uppercase tracking-widest font-mono mb-4">Série très exclusive</span>
                  
                  <p className="text-gray-300 font-sans font-light text-xs leading-relaxed mb-6">
                    {item.description}
                  </p>

                  <div className="space-y-2 mb-6">
                    {item.details.slice(0, 3).map((detail, idx) => (
                      <div key={idx} className="flex items-start gap-2 text-[11px] text-gray-400">
                        <Check className="w-3.5 h-3.5 text-gold shrink-0 mt-0.5" />
                        <span>{detail}</span>
                      </div>
                    ))}
                  </div>

                  <button
                    onClick={() => setActiveItem(item)}
                    className="w-full py-2.5 border border-gold/40 text-gold hover:bg-gold hover:text-rich-black text-xs uppercase tracking-widest font-sans font-semibold transition-all duration-300 rounded-none text-center"
                  >
                    Examiner les Détails
                  </button>
                </div>
              </div>

              {/* Informative Footer */}
              <div className="p-6 bg-[#161616] border-t border-gold/5 flex flex-col flex-grow justify-between">
                <div>
                  <h3 className="font-display text-lg text-white group-hover:text-gold transition-colors uppercase tracking-wider mb-2">
                    {item.title}
                  </h3>
                  <p className="text-gray-400 font-sans font-light text-xs line-clamp-2 mb-4 leading-relaxed">
                    {item.description}
                  </p>
                </div>
                
                <div className="flex items-center justify-between pt-4 border-t border-white/5 mt-auto">
                  <div>
                    <span className="block text-[9px] text-gold/60 uppercase font-mono tracking-wider">Prix de l'Oeuvre</span>
                    <span className="font-mono text-base font-semibold text-[#FFEAB5] tracking-wide">{item.price}</span>
                  </div>
                  
                  <button
                    onClick={() => handleWhatsAppOrder(item)}
                    className="flex items-center gap-2 px-4 py-2 bg-[#128C7E] hover:bg-[#25D366] text-white text-[10px] uppercase tracking-widest font-sans font-bold transition-colors shadow-md rounded-sm"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    Commander WhatsApp
                  </button>
                </div>
              </div>

            </motion.div>
          ))}
        </div>

        {/* Brand Luxury Manifesto */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="mt-20 border border-gold/15 bg-gradient-to-r from-rich-black to-[#111] p-8 md:p-12 text-center max-w-4xl mx-auto"
        >
          <p className="font-sans font-light italic text-[#E8E8E8] text-base md:text-lg mb-4">
            "Chaque pièce conçue à l'Atelier d'EMZ est un pont entre l'élégance coutumière et le futurisme artistique d'Afrique. 
            Nos artistes ne créent pas seulement du rythme, ils sculptent l'allure d'une nouvelle ère prestigieuse."
          </p>
          <span className="font-mono text-xs uppercase tracking-widest text-[#C9A84C]">— La Direction Artistique EMZ RECORD</span>
        </motion.div>

      </div>

      {/* Deluxe Overlaid Detail Modal */}
      <AnimatePresence>
        {activeItem && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md"
          >
            <motion.div
              initial={{ scale: 0.95, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 20 }}
              className="bg-[#121212] border border-gold/30 rounded-none w-full max-w-4xl h-auto max-h-[90vh] overflow-y-auto relative shadow-2xl flex flex-col md:flex-row"
            >
              <button
                onClick={() => setActiveItem(null)}
                className="absolute top-4 right-4 text-gray-400 hover:text-white bg-black/60 p-2 border border-gold/20 rounded-full z-10 transition-colors"
                aria-label="Fermer la vue"
              >
                <X className="w-5 h-5" />
              </button>

              {/* Product Image Section */}
              <div className="w-full md:w-1/2 aspect-square md:aspect-auto md:min-h-[450px] relative bg-black">
                <img
                  src={activeItem.image}
                  alt={activeItem.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-4 left-4 bg-rich-black/90 border border-gold/30 px-3 py-1 text-xs tracking-widest text-gold uppercase font-mono">
                  Édition Certifiée
                </div>
              </div>

              {/* Product Details Description Section */}
              <div className="w-full md:w-1/2 p-8 md:p-12 flex flex-col justify-between">
                <div>
                  <span className="text-[10px] tracking-[0.25em] text-gold font-mono uppercase block mb-2">
                    Création Exclusive — {activeItem.artistCreator}
                  </span>
                  
                  <h3 className="font-display text-2xl md:text-3xl lg:text-4xl text-white uppercase tracking-normal mb-4">
                    {activeItem.title}
                  </h3>
                  
                  <span className="text-2xl font-mono text-[#FFEAB5] block pb-4 border-b border-white/10 mb-6">
                    {activeItem.price}
                  </span>

                  <p className="text-gray-300 font-sans font-light text-sm leading-relaxed mb-6">
                    {activeItem.description}
                  </p>

                  <div className="space-y-3 mb-8">
                    <h5 className="text-[10px] tracking-widest uppercase font-mono font-bold text-gray-400">Détails d'Artisanat d'Élite :</h5>
                    <ul className="space-y-2">
                      {activeItem.details.map((detail, idx) => (
                        <li key={idx} className="flex items-start gap-2.5 text-xs text-gray-400">
                          <Check className="w-4 h-4 text-gold shrink-0 mt-0.5" />
                          <span>{detail}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row gap-4">
                  <button
                    onClick={() => handleWhatsAppOrder(activeItem)}
                    className="flex-1 flex items-center justify-center gap-2 py-3 bg-[#128C7E] hover:bg-[#25D366] text-white text-xs uppercase tracking-widest font-sans font-bold transition-colors shadow-md rounded-sm"
                  >
                    <MessageCircle className="w-4 h-4" />
                    Commander Directement
                  </button>
                  
                  <button
                    onClick={() => setActiveItem(null)}
                    className="flex-1 py-3 border border-white/20 text-gray-400 hover:border-gold hover:text-white text-xs uppercase tracking-widest font-sans font-medium transition-all"
                  >
                    Fermer l'Atelier
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
