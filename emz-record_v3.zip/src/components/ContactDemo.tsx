import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Send, CheckCircle, Mail, Phone, MapPin, Disc, AlertCircle } from 'lucide-react';
import { DemoSubmission } from '../types';

export default function ContactDemo() {
  const [formData, setFormData] = useState<DemoSubmission>({
    artistName: '',
    email: '',
    trackTitle: '',
    genre: 'Afro-Fusion',
    demoLink: '',
    message: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const genres = ['Afro-Fusion', 'Afro-Trap', 'Soul & R&B', 'Orchestral Trad', 'Amapiano de Luxe'];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errorMessage) setErrorMessage('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.artistName || !formData.email || !formData.trackTitle || !formData.demoLink) {
      setErrorMessage("Veuillez remplir tous les champs requis marked d'un astérisque (*).");
      return;
    }

    if (!formData.demoLink.startsWith('http://') && !formData.demoLink.startsWith('https://')) {
      setErrorMessage("Le lien de la démo doit commencer par http:// ou https://");
      return;
    }

    setIsSubmitting(true);

    // Simulate luxury record checking
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
      setFormData({
        artistName: '',
        email: '',
        trackTitle: '',
        genre: 'Afro-Fusion',
        demoLink: '',
        message: ''
      });
    }, 2000);
  };

  return (
    <section id="contact" className="py-24 bg-luxury-gray relative">
      <div className="absolute bottom-0 right-0 w-[300px] h-[300px] bg-gold/5 blur-[120px] rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6">
        
        {/* Section Title Header */}
        <div className="mb-16">
          <span className="text-xs uppercase tracking-[0.3em] text-gold font-sans font-medium block mb-2">
            Entrez dans l'Histoire
          </span>
          <h2 className="font-display text-5xl md:text-6xl tracking-wide uppercase text-white">
            Contact & <span className="gold-gradient-text font-light">Auditions</span>
          </h2>
          <div className="w-16 h-[2px] bg-gold mt-4" />
        </div>

        {/* Layout Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Left Column: Prestigious Concierge Information */}
          <div className="lg:col-span-5 flex flex-col justify-between h-full space-y-12">
            <div className="space-y-6">
              <h3 className="font-display text-3xl text-white tracking-widest uppercase mb-4">
                Le Secrétariat EMZ
              </h3>
              <p className="text-gray-400 font-sans font-light text-sm leading-relaxed mb-8">
                Pour toute demande de privatisation de studio, de production publicitaire, de partenariats ou d'interview de notre Roster. Notre concierge de luxe vous répondra sous 24h ouvrées.
              </p>

              {/* Specific info rows */}
              <div className="space-y-4">
                <div className="flex items-center gap-4 text-sm text-gray-300">
                  <div className="p-3 bg-rich-black border border-gold/10 text-gold rounded-sm">
                    <Mail className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-[10px] uppercase tracking-widest text-[#C9A84C]/80 font-mono leading-none mb-1">E-mail de Luxe</h4>
                    <p className="font-sans font-medium text-sm">concierge@emzrecord.luxury</p>
                  </div>
                </div>

                <a 
                  href="https://wa.me/22672366484?text=Bonjour%20EMZ%20RECORD%2C%20je%20souhaite%20entrer%20en%20contact%20avec%20la%20ligne%20principale."
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-4 text-sm text-gray-300 cursor-pointer group/whats p-3 bg-rich-black hover:bg-[#128C7E]/10 border border-gold/10 hover:border-[#128C7E]/40 rounded-sm transition-all duration-300"
                >
                  <div className="p-3 bg-[#128C7E]/20 text-[#25D366] group-hover/whats:scale-110 transition-transform duration-300 rounded-sm">
                    <Phone className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-[10px] uppercase tracking-widest text-[#25D366] font-mono leading-none mb-1 flex items-center gap-1.5">
                      <span>WhatsApp Principal</span>
                      <span className="w-1.5 h-1.5 rounded-full bg-[#25D366] animate-ping" />
                    </h4>
                    <p className="font-sans font-medium text-sm group-hover/whats:text-[#25D366] transition-colors">+226 72 36 64 84</p>
                  </div>
                </a>

                <a 
                  href="https://wa.me/22676319216?text=Bonjour%20EMZ%20RECORD%2C%20je%20souhaite%20entrer%20en%20contact%20avec%20la%20ligne%20secondaire."
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-4 text-sm text-gray-300 cursor-pointer group/whats p-3 bg-rich-black hover:bg-[#128C7E]/10 border border-gold/10 hover:border-[#128C7E]/40 rounded-sm transition-all duration-300"
                >
                  <div className="p-3 bg-[#128C7E]/20 text-[#25D366] group-hover/whats:scale-110 transition-transform duration-300 rounded-sm">
                    <Phone className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-[10px] uppercase tracking-widest text-[#25D366] font-mono leading-none mb-1 flex items-center gap-1.5">
                      <span>WhatsApp Concierge</span>
                      <span className="w-1.5 h-1.5 rounded-full bg-[#25D366] animate-ping animate-duration-1000" />
                    </h4>
                    <p className="font-sans font-medium text-sm group-hover/whats:text-[#25D366] transition-colors">+226 76 31 92 16</p>
                  </div>
                </a>

                <div className="flex items-center gap-4 text-sm text-gray-300">
                  <div className="p-3 bg-rich-black border border-gold/10 text-gold rounded-sm">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-[10px] uppercase tracking-widest text-[#C9A84C]/80 font-mono leading-none mb-1">Maison Mère</h4>
                    <p className="font-sans font-medium text-sm">Avenue de l'Indépendance, Ouagadougou</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Micro aesthetic decorative element */}
            <div className="border border-gold/10 p-6 rounded-sm bg-rich-black/50">
              <h4 className="text-xs tracking-widest font-sans font-bold text-[#C9A84C] uppercase mb-2">Note Importante</h4>
              <p className="text-gray-500 font-sans font-light text-xs leading-relaxed">
                Le label n'écoute pas les démos physiques envoyées par courrier. Veuillez utiliser le formulaire dédié ci-contre pour soumettre vos créations numériques sous format SoundCloud, YouTube, Dropbox ou Drive.
              </p>
            </div>
          </div>

          {/* Right Column: "Soumettre une Démo" Form (Isolated with thin 1px gold border) */}
          <div className="lg:col-span-7">
            <div className="relative border border-gold bg-rich-black/80 backdrop-blur-md p-8 md:p-10 rounded-sm shadow-2xl overflow-hidden">
              
              {/* Background accent disc decorative */}
              <div className="absolute top-0 right-0 w-24 h-24 bg-gold/5 rounded-full blur-xl pointer-events-none" />

              <div className="mb-8">
                <span className="text-[10px] uppercase tracking-[0.25em] text-[#C9A84C] font-mono block mb-1">
                  Section d'Auditions Élite
                </span>
                <h3 className="font-display text-3xl text-white tracking-widest uppercase">
                  Soumettre une Démo
                </h3>
                <p className="text-xs text-gray-400 font-sans mt-2">
                  Nos directeurs de casting écoutent chaque soumission avec rigueur. Si votre son correspond à notre vision d'excellence, nous vous recontacterons.
                </p>
              </div>

              <AnimatePresence mode="wait">
                {!isSubmitted ? (
                  <motion.form
                    key="form-demo"
                    initial={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    onSubmit={handleSubmit}
                    className="space-y-6"
                  >
                    {/* Error Alerts */}
                    {errorMessage && (
                      <div className="p-4 bg-red-950/40 border border-red-500/30 text-red-200 text-xs rounded-sm flex items-center gap-2">
                        <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                        <span>{errorMessage}</span>
                      </div>
                    )}

                    {/* Artist & Email */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="flex flex-col">
                        <label className="text-[10px] tracking-widest uppercase text-gray-400 font-sans mb-2 font-medium">
                          Nom d'Artiste / Groupe *
                        </label>
                        <input
                          type="text"
                          name="artistName"
                          placeholder="Ex: Ayra Gold"
                          value={formData.artistName}
                          onChange={handleInputChange}
                          className="px-4 py-3 bg-luxury-gray border border-gold/15 text-white placeholder-gray-600 focus:outline-none focus:border-gold transition-colors text-sm rounded-sm"
                          required
                        />
                      </div>
                      <div className="flex flex-col">
                        <label className="text-[10px] tracking-widest uppercase text-gray-400 font-sans mb-2 font-medium">
                          Adresse E-mail de Contact *
                        </label>
                        <input
                          type="email"
                          name="email"
                          placeholder="artist@example.com"
                          value={formData.email}
                          onChange={handleInputChange}
                          className="px-4 py-3 bg-luxury-gray border border-gold/15 text-white placeholder-gray-600 focus:outline-none focus:border-gold transition-colors text-sm rounded-sm"
                          required
                        />
                      </div>
                    </div>

                    {/* Track Title & Genre */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="flex flex-col">
                        <label className="text-[10px] tracking-widest uppercase text-gray-400 font-sans mb-2 font-medium">
                          Titre de la Maquette *
                        </label>
                        <input
                          type="text"
                          name="trackTitle"
                          placeholder="Ex: Vibres Dorées (DÉMO)"
                          value={formData.trackTitle}
                          onChange={handleInputChange}
                          className="px-4 py-3 bg-luxury-gray border border-gold/15 text-white placeholder-gray-600 focus:outline-none focus:border-gold transition-colors text-sm rounded-sm"
                          required
                        />
                      </div>
                      <div className="flex flex-col">
                        <label className="text-[10px] tracking-widest uppercase text-gray-400 font-sans mb-2 font-medium">
                          Genre Musical Principal
                        </label>
                        <select
                          name="genre"
                          value={formData.genre}
                          onChange={handleInputChange}
                          className="px-4 py-3 bg-luxury-gray border border-gold/15 text-white focus:outline-none focus:border-gold transition-colors text-sm rounded-sm"
                        >
                          {genres.map((g) => (
                            <option key={g} value={g} className="bg-rich-black text-white">
                              {g}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>

                    {/* Demo Link */}
                    <div className="flex flex-col">
                      <label className="text-[10px] tracking-widest uppercase text-gray-400 font-sans mb-2 font-medium">
                        Lien d'Écoute (SoundCloud, Drive, YouTube, DropBox) *
                      </label>
                      <input
                        type="url"
                        name="demoLink"
                        placeholder="https://soundcloud.com/vos-vibes"
                        value={formData.demoLink}
                        onChange={handleInputChange}
                        className="px-4 py-3 bg-luxury-gray border border-gold/15 text-white placeholder-gray-600 focus:outline-none focus:border-gold transition-colors text-sm rounded-sm"
                        required
                      />
                    </div>

                    {/* Message / Presentation */}
                    <div className="flex flex-col">
                      <label className="text-[10px] tracking-widest uppercase text-gray-400 font-sans mb-2 font-medium">
                        Présentation rapide / Motivation
                      </label>
                      <textarea
                        name="message"
                        rows={4}
                        placeholder="Parlez-nous de votre vision artistique, de vos influences..."
                        value={formData.message}
                        onChange={handleInputChange}
                        className="px-4 py-3 bg-luxury-gray border border-gold/15 text-white placeholder-gray-600 focus:outline-none focus:border-gold transition-colors text-sm rounded-sm resize-none"
                      />
                    </div>

                    {/* Submit Button */}
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full relative py-4 bg-gold hover:bg-gold-hover text-rich-black text-xs font-sans uppercase font-bold tracking-widest rounded-sm transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                    >
                      {isSubmitting ? (
                        <>
                          <Disc className="w-4 h-4 animate-spin" />
                          <span>Analyse de l'onde sonore...</span>
                        </>
                      ) : (
                        <>
                          <Send className="w-4 h-4" />
                          <span>Soumettre mon Chef-d'œuvre</span>
                        </>
                      )}
                    </button>
                  </motion.form>
                ) : (
                  /* Success Feedback block */
                  <motion.div
                    key="success"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="text-center py-12 flex flex-col items-center"
                  >
                    <CheckCircle className="w-16 h-16 text-gold mb-6 animate-pulse" />
                    <h4 className="font-display text-2xl text-white tracking-widest uppercase mb-4">
                      Soumission Reçue avec Succès !
                    </h4>
                    <p className="text-gray-400 font-sans text-sm max-w-md mx-auto leading-relaxed mb-8">
                      Votre projet a été scellé dans nos archives d'élite. Notre comité d'écoute composé de nos producteurs de renom et de notre direction artistique l'analysera avec la plus grande considération.
                    </p>
                    <button
                      onClick={() => setIsSubmitted(false)}
                      className="px-6 py-2 border border-gold/30 text-gold hover:border-gold hover:bg-gold hover:text-rich-black transition-all text-xs tracking-widest uppercase font-sans"
                    >
                      Soumettre une Autre Démo
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
