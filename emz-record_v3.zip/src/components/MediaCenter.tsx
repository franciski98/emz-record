import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Play, Pause, SkipForward, SkipBack, Volume2, VolumeX, Download, Music, Coins, Laptop, Disc, ShieldCheck, ShoppingBag, Radio, Sparkles, HelpCircle } from 'lucide-react';
import { ROSTER } from '../data';

interface Track {
  id: string;
  title: string;
  artist: string;
  genre: string;
  duration: number; // in seconds
  royaltyRate: number; // fake royalty generated per second in FCFA
  isFreeToPlay: boolean;
  price?: number; // if paid
  image: string;
}

export default function MediaCenter() {
  const tracks: Track[] = [
    {
      id: "track-vibe",
      title: "Vibrations d'Or (Symphonie Royale)",
      artist: "KOSA PIC",
      genre: "Afro-Fusion Deluxe",
      duration: 215,
      royaltyRate: 0.85,
      isFreeToPlay: true,
      image: ROSTER.find(a => a.id === "kosa-pic")?.image || ""
    },
    {
      id: "track-salby",
      title: "Cœur Vaillant (Solaire Vibe)",
      artist: "SALBY",
      genre: "Afro-Pop Solaire",
      duration: 204,
      royaltyRate: 0.88,
      isFreeToPlay: true,
      image: ROSTER.find(a => a.id === "salby")?.image || ""
    },
    {
      id: "track-josby",
      title: "Red Bandana (Trap Royale)",
      artist: "JOSBY",
      genre: "Trap Afro-Moderne",
      duration: 182,
      royaltyRate: 0.92,
      isFreeToPlay: true,
      image: ROSTER.find(a => a.id === "josby")?.image || ""
    },
    {
      id: "track-lima",
      title: "Reine du Stade (Live Symphonie)",
      artist: "LIMA",
      genre: "Urban Diva & Live Afro",
      duration: 228,
      royaltyRate: 0.95,
      isFreeToPlay: true,
      image: ROSTER.find(a => a.id === "lima")?.image || ""
    },
    {
      id: "track-bandita",
      title: "Le Retour du Bandita (Acoustic)",
      artist: "EL BANDITA",
      genre: "Afro-Street Libre",
      duration: 185,
      royaltyRate: 0.78,
      isFreeToPlay: true,
      image: ROSTER.find(a => a.id === "el-bandita")?.image || ""
    },
    {
      id: "track-souverain",
      title: "Souverain (Afro-Groove Edition)",
      artist: "FLOWMAN BOY",
      genre: "Afro-Vibe Majestic",
      duration: 198,
      royaltyRate: 0.72,
      isFreeToPlay: true,
      image: ROSTER.find(a => a.id === "flowman-boy")?.image || ""
    },
    {
      id: "track-rapide",
      title: "Chessboard Flow (Rimes d'Or)",
      artist: "DJO LE RAPIDE",
      genre: "Elite Rap",
      duration: 174,
      royaltyRate: 0.95,
      isFreeToPlay: true,
      image: ROSTER.find(a => a.id === "djo-le-rapide")?.image || ""
    },
    {
      id: "track-boss",
      title: "Or Noir (Deep Amapiano)",
      artist: "HUGO BOSS",
      genre: "Amapiano de Prestige",
      duration: 252,
      royaltyRate: 0.65,
      isFreeToPlay: true,
      image: ROSTER.find(a => a.id === "hugo-boss")?.image || ""
    }
  ];

  // Exclusive albums & single tracks that can be paid and downloaded
  const exclusives = [
    {
      id: "ex-album-kosapic",
      title: "Vibrations d'Or (Album Master)",
      artist: "KOSA PIC",
      type: "ALBUM COMPLET (WAV Master)",
      price: 5000,
      tracksCount: 12,
      image: ROSTER.find(a => a.id === "kosa-pic")?.image || "",
      description: "Le chef-d'œuvre intégral du chanteur vedette en version audio non-compressée studio master, ornée du livret numérique exclusif haute couture."
    },
    {
      id: "ex-album-salby",
      title: "Rayonnement (Album Deluxe)",
      artist: "SALBY",
      type: "ALBUM COMPLET (Hi-Res Flac)",
      price: 4500,
      tracksCount: 11,
      image: ROSTER.find(a => a.id === "salby")?.image || "",
      description: "L'opus solaire de SALBY regroupant ses plus grands refrains d'or et ses featurings d'exception en direct du Faso."
    },
    {
      id: "ex-album-josby",
      title: "Écarlate (EP Trap Master)",
      artist: "JOSBY",
      type: "EP EXCLUSIF (WAV 24-bit)",
      price: 3500,
      tracksCount: 6,
      image: ROSTER.find(a => a.id === "josby")?.image || "",
      description: "La déflagration trap de JOSBY avec productions lourdes, stems instrumentaux et pistes vocales studio isolées."
    },
    {
      id: "ex-album-lima",
      title: "Reine Incontestée (Concert Live)",
      artist: "LIMA",
      type: "ALBUM LIVE (Audio Spatial Master)",
      price: 5000,
      tracksCount: 14,
      image: ROSTER.find(a => a.id === "lima")?.image || "",
      description: "La captation audio intégrale en direct des plus grands stades de la tournée ouest-africaine de la diva LIMA."
    },
    {
      id: "ex-album-bandita",
      title: "La Voix du Peuple (Master Edition)",
      artist: "EL BANDITA",
      type: "ALBUM COLLECTOR (WAV Master)",
      price: 4000,
      tracksCount: 9,
      image: ROSTER.find(a => a.id === "el-bandita")?.image || "",
      description: "L'œuvre engagée et poignante d'El Bandita enregistrée avec des instruments traditionnels et guitares live."
    },
    {
      id: "ex-album-flowman",
      title: "SOUVERAIN (Édition Prestige)",
      artist: "FLOWMAN BOY",
      type: "ALBUM COLLECTOR (WAV Master)",
      price: 4500,
      tracksCount: 10,
      image: ROSTER.find(a => a.id === "flowman-boy")?.image || "",
      description: "L'édition suprême certifiée Or de FLOWMAN BOY. Mixage exclusif pour les systèmes Hi-Fi haut de gamme."
    },
    {
      id: "ex-single-djo",
      title: "Chessboard Flow (Pack Producer)",
      artist: "DJO LE RAPIDE",
      type: "SINGLE + STEMS (Wave Studio)",
      price: 2500,
      tracksCount: 3,
      image: ROSTER.find(a => a.id === "djo-le-rapide")?.image || "",
      description: "Contient le single master, l'acapella de studio officiel isolé et la piste instrumentale originale de prestige pour les DJ."
    },
    {
      id: "ex-group-weler",
      title: "Aura Or Live Sessions (Ep)",
      artist: "WELER GANG",
      type: "EP LIVE (Hi-Res Audio)",
      price: 3000,
      tracksCount: 5,
      image: ROSTER.find(a => a.id === "weler-gang")?.image || "",
      description: "Cinq titres enregistrés en direct à l'Hôtel de la Paix, accompagnés des improvisations d'élites de tout le collectif."
    }
  ];

  // State managers
  const [currentTrackIndex, setCurrentTrackIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [volume, setVolume] = useState(0.8);
  const [isMuted, setIsMuted] = useState(false);
  const [cumulativeRoyalties, setCumulativeRoyalties] = useState(0);
  const [royaltiesPerArtist, setRoyaltiesPerArtist] = useState<Record<string, number>>({});
  const [unlockedDownloads, setUnlockedDownloads] = useState<string[]>([]);
  
  // Shopping states
  const [selectedEx, setSelectedEx] = useState<typeof exclusives[0] | null>(null);
  const [isPurchaseModalOpen, setIsPurchaseModalOpen] = useState(false);
  const [purchaseStep, setPurchaseStep] = useState<'checkout' | 'processing' | 'unlocked'>('checkout');
  const [buyerName, setBuyerName] = useState('');
  const [buyerPhone, setBuyerPhone] = useState('');
  const [payingOperator, setPayingOperator] = useState<'orange' | 'moov' | 'wave' | 'card'>('orange');

  const currentTrack = tracks[currentTrackIndex];
  const progressPercent = (currentTime / currentTrack.duration) * 100;

  // Simulator interval for music play time & royalty accrual
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (isPlaying) {
      interval = setInterval(() => {
        setCurrentTime((prev) => {
          if (prev >= currentTrack.duration) {
            // Loop or skip to next
            handleNext();
            return 0;
          }
          return prev + 1;
        });

        // Earn royalties!
        const rate = currentTrack.royaltyRate;
        setCumulativeRoyalties(prev => prev + rate);
        
        // Accumulate specific artist royalty counts
        setRoyaltiesPerArtist(prev => {
          const prevVal = prev[currentTrack.artist] || 0;
          return {
            ...prev,
            [currentTrack.artist]: Number((prevVal + rate).toFixed(2))
          };
        });

      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isPlaying, currentTrackIndex]);

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const handleNext = () => {
    setCurrentTime(0);
    setCurrentTrackIndex((prev) => (prev + 1) % tracks.length);
  };

  const handlePrev = () => {
    setCurrentTime(0);
    setCurrentTrackIndex((prev) => (prev - 1 + tracks.length) % tracks.length);
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
  };

  const formatTime = (secs: number) => {
    const min = Math.floor(secs / 60);
    const sec = secs % 60;
    return `${min}:${sec < 10 ? '0' : ''}${sec}`;
  };

  // Direct mock download triggers
  const executeDownload = (title: string) => {
    alert(`Téléchargement de l'exclusivité d'or "${title}" démarré ! (Fichier Studio Master WAV de haute fidélité simulé)`);
    // Programmatic trigger of basic text blob 
    const element = document.createElement("a");
    const file = new Blob([`Fichier Master Audio Certifie EMZ RECORD: ${title}`], {type: 'text/plain'});
    element.href = URL.createObjectURL(file);
    element.download = `${title.toLowerCase().replace(/[^a-z0-9]/g, "_")}_emz_master.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  // Open store purchase sheet
  const handleOpenPurchase = (ex: typeof exclusives[0]) => {
    // If already unlocked
    if (unlockedDownloads.includes(ex.id)) {
      executeDownload(ex.title);
      return;
    }
    setSelectedEx(ex);
    setPurchaseStep('checkout');
    setBuyerName('');
    setBuyerPhone('');
    setIsPurchaseModalOpen(true);
  };

  const processPurchaseSimulation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!buyerName.trim()) {
      alert("Veuillez renseigner votre nom pour le reçu fiscal d'art.");
      return;
    }
    if (payingOperator !== 'card' && !buyerPhone.trim()) {
      alert("Veuillez renseigner votre numéro de mobile de paiement.");
      return;
    }

    setPurchaseStep('processing');
    
    setTimeout(() => {
      if (selectedEx) {
        setUnlockedDownloads(prev => [...prev, selectedEx.id]);
        setPurchaseStep('unlocked');
      }
    }, 2800);
  };

  return (
    <section id="media-center" className="py-24 bg-luxury-gray relative border-t border-gold/10">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_80%,rgba(199,168,76,0.04),transparent_50%)] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6">
        
        {/* Title row */}
        <div className="mb-16">
          <span className="text-xs uppercase tracking-[0.3em] text-gold font-sans font-medium block mb-2">
            Maison de Distribution Numérique Directe
          </span>
          <h2 className="font-display text-4xl md:text-5xl tracking-wide uppercase text-white">
            Royalties & <span className="gold-gradient-text font-light">Exclusivités</span>
          </h2>
          <div className="w-16 h-[2px] bg-gold mt-4" />
        </div>

        {/* Layout grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* LEFT 5 COLS: PERSISTENT ROYAL PLAYER BOARD */}
          <div className="lg:col-span-5 bg-rich-black border border-gold/15 p-6 rounded-sm shadow-2xl relative overflow-hidden">
            <span className="absolute top-4 right-4 text-[9px] font-mono tracking-widest text-gold text-gold/60 uppercase flex items-center gap-1.5 bg-luxury-gray px-2 py-1 rounded border border-gold/5">
              <Radio className="w-3 h-3 text-gold animate-pulse" />
              <span>ROSTER STREAM ON</span>
            </span>

            {/* Simulated cover disk */}
            <div className="flex flex-col items-center text-center mt-4 mb-6">
              <div className="relative w-40 h-40 rounded-full bg-zinc-950 p-2 border border-gold/15 shadow-xl group justify-center items-center flex">
                {/* Vinyl record spinning */}
                <div className={`absolute inset-2 rounded-full border-4 border-zinc-800 bg-cover bg-center transition-transform ${
                  isPlaying ? 'animate-spin' : ''
                }`} style={{ backgroundImage: `url(${currentTrack.image})`, animationDuration: '8s' }}>
                  <div className="absolute inset-0 bg-black/10 rounded-full" />
                </div>
                {/* Center hole design */}
                <div className="w-12 h-12 rounded-full bg-rich-black border border-gold/25 z-10 flex items-center justify-center">
                  <div className="w-3 h-3 rounded-full bg-zinc-950" />
                </div>
              </div>

              <div className="mt-4">
                <h3 className="font-display text-lg text-white tracking-wide truncate max-w-[280px]">
                  {currentTrack.title}
                </h3>
                <p className="text-xs text-gold uppercase tracking-widest font-mono font-medium mt-1">
                  {currentTrack.artist}
                </p>
                <span className="text-[9px] font-mono text-gray-500 uppercase tracking-wider block mt-1">
                  {currentTrack.genre}
                </span>
              </div>
            </div>

            {/* Equalizer Visualizer Bars */}
            <div className="h-10 flex items-end justify-center gap-1.5 mb-6 px-10">
              {[...Array(15)].map((_, i) => {
                const heights = [16, 24, 32, 12, 40, 20, 28, 36, 14, 25, 30, 18, 35, 22, 10];
                const animDuration = [0.6, 0.7, 0.5, 0.8, 0.65, 0.75, 0.55, 0.9, 0.6, 0.85, 0.5, 0.7, 0.8, 0.65, 0.73];
                return (
                  <div 
                    key={i} 
                    className="w-1.5 bg-gradient-to-t from-gold/50 to-gold rounded-t-sm"
                    style={{ 
                      height: isPlaying ? '100%' : '3px',
                      maxHeight: `${heights[i]}px`,
                      animation: isPlaying ? `equalizer ${animDuration[i]}s ease-in-out infinite alternate` : 'none',
                      animationDelay: `${i * 0.05}s`
                    }}
                  />
                );
              })}
            </div>

            {/* Time progress indicators slider */}
            <div className="space-y-2 mb-6">
              <div className="w-full h-1 bg-zinc-900 rounded-full overflow-hidden relative cursor-pointer group">
                <div 
                  className="h-full bg-gold absolute left-0 top-0 transition-all duration-300"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
              <div className="flex justify-between font-mono text-[10px] text-gray-500">
                <span>{formatTime(currentTime)}</span>
                <span>{formatTime(currentTrack.duration)}</span>
              </div>
            </div>

            {/* Player Controllers */}
            <div className="flex items-center justify-center gap-6 mb-8">
              <button 
                onClick={handlePrev}
                className="p-2 text-gray-400 hover:text-gold transition-colors focus:outline-none cursor-pointer"
                title="Précédent"
              >
                <SkipBack className="w-5 h-5" />
              </button>

              <button 
                onClick={handlePlayPause}
                className="w-12 h-12 rounded-full bg-gold text-rich-black flex items-center justify-center hover:scale-105 transition-transform shadow-lg focus:outline-none cursor-pointer"
                title={isPlaying ? "Pause" : "Play"}
              >
                {isPlaying ? <Pause className="w-5 h-5 fill-rich-black text-rich-black" /> : <Play className="w-5 h-5 fill-rich-black text-rich-black translate-x-[1px]" />}
              </button>

              <button 
                onClick={handleNext}
                className="p-2 text-gray-400 hover:text-gold transition-colors focus:outline-none cursor-pointer"
                title="Suivant"
              >
                <SkipForward className="w-5 h-5" />
              </button>

              <button 
                onClick={toggleMute}
                className="p-2 text-gray-400 hover:text-gold transition-colors focus:outline-none cursor-pointer"
                title={isMuted ? "Unmute" : "Mute"}
              >
                {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              </button>
            </div>

            {/* Royalty Metric Widget (Simulate interactive earnings for listening) */}
            <div className="bg-luxury-gray/70 border border-gold/10 p-4 rounded-sm">
              <div className="flex items-center gap-2 mb-2">
                <Coins className="w-4 h-4 text-gold" />
                <span className="text-[10px] font-mono tracking-widest text-[#C9A84C] font-semibold uppercase">PRESTIGE ROCO - GENÉRATEUR DE ROYALTIES</span>
              </div>
              <p className="text-[11px] text-gray-400 font-sans leading-relaxed mb-3">
                Chaque seconde d'écoute sur notre portail génère de l'or d'artiste. Laissez le lecteur tourner pour augmenter l'autonomie financière de notre roster !
              </p>
              
              <div className="grid grid-cols-2 gap-3 pt-3 border-t border-gold/5">
                <div>
                  <span className="block text-[9px] text-gray-500 font-mono uppercase">VOS ROYALTIES GÉNÉRÉES</span>
                  <span className="text-sm font-sans font-extrabold text-gold">
                    {cumulativeRoyalties.toFixed(2)} FCFA
                  </span>
                </div>
                <div>
                  <span className="block text-[9px] text-gray-500 font-mono uppercase">Vitesse en cours</span>
                  <span className="text-sm font-sans font-medium text-white flex items-center gap-1">
                    <span>+{currentTrack.royaltyRate} FCFA</span>
                    <span className="text-[9px] text-gray-500">/sec</span>
                  </span>
                </div>
              </div>
            </div>

            {/* Small playlist listing */}
            <div className="mt-6 border-t border-gold/10 pt-4 space-y-2">
              <span className="text-[10px] font-mono text-gray-500 tracking-wider uppercase block mb-2">Pistes Disponibles :</span>
              <div className="space-y-1 max-h-[160px] overflow-y-auto pr-1">
                {tracks.map((t, idx) => (
                  <button
                    key={t.id}
                    onClick={() => {
                      setCurrentTrackIndex(idx);
                      setCurrentTime(0);
                      setIsPlaying(true);
                    }}
                    className={`w-full text-left p-2 rounded-sm text-xs transition-colors flex items-center justify-between cursor-pointer ${
                      currentTrackIndex === idx ? 'bg-gold/15 text-gold font-medium' : 'hover:bg-luxury-gray/40 text-gray-400'
                    }`}
                  >
                    <div className="flex items-center gap-2 truncate max-w-[70%]">
                      <Music className="w-3.5 h-3.5" />
                      <span className="truncate">{t.title}</span>
                    </div>
                    <span className="font-mono text-[10px] text-gray-500">{t.artist}</span>
                  </button>
                ))}
              </div>
            </div>

          </div>

          {/* RIGHT 7 COLS: DIRECT COUTURE MUSIC DOWNLOAD STORE */}
          <div className="lg:col-span-7 space-y-6">
            <div className="bg-rich-black/30 border border-gold/5 p-6 rounded-sm">
              <span className="text-xs font-mono uppercase text-gold tracking-widest block mb-1">PUBLICATION EXCLUSIVE DIRECTE</span>
              <h3 className="font-display text-2xl text-white tracking-widest uppercase mb-2">Exclusivités Master Premium</h3>
              <p className="text-xs text-gray-400 font-sans leading-relaxed">
                Achetez et téléchargez nos albums et singles d'élite en version authentique Studio WAV (24 bits/96 kHz). En achetant ici sans intermédiaire, <strong>85% du prix est directement versé</strong> à l'artiste créateur pour la pérennité culturelle de sa musique. Paiement Mobile Money instantané et sécurisé.
              </p>
            </div>

            {/* List of digital music packs */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {exclusives.map((ex) => {
                const isUnlocked = unlockedDownloads.includes(ex.id);
                return (
                  <div 
                    key={ex.id}
                    className="bg-rich-black border border-gold/10 hover:border-gold/20 p-5 rounded-sm flex flex-col justify-between transition-all duration-300"
                  >
                    <div>
                      <div className="relative h-40 bg-zinc-900 rounded-sm overflow-hidden mb-4">
                        <img 
                          src={ex.image} 
                          alt={ex.title} 
                          className="w-full h-full object-cover grayscale opacity-80"
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-rich-black via-rich-black/30 to-transparent" />
                        <span className="absolute bottom-3 left-3 bg-rich-black/80 text-xs font-mono text-gold px-2 py-0.5 rounded border border-gold/10">
                          {ex.type}
                        </span>
                      </div>

                      <div className="space-y-1">
                        <span className="text-[10px] font-mono tracking-widest uppercase text-gold/80 block">
                          {ex.artist}
                        </span>
                        <h4 className="font-display text-lg text-white tracking-wide truncate">
                          {ex.title}
                        </h4>
                        <span className="text-[10px] font-sans text-gray-500 block">
                          Contient {ex.tracksCount} pistes de prestige • Haute Fidélité WAV
                        </span>
                        <p className="text-[11px] text-gray-400 font-sans leading-normal line-clamp-2 mt-2 font-light">
                          {ex.description}
                        </p>
                      </div>
                    </div>

                    <div className="pt-4 border-t border-gold/5 mt-4 flex items-center justify-between gap-2">
                      <div className="text-left">
                        <span className="text-[9px] font-mono text-gray-500 uppercase block">PRIX DE L'EUVRE</span>
                        <span className="text-sm font-sans font-bold text-white">
                          {isUnlocked ? "PAGÉ ET ACCQUIS" : `${ex.price.toLocaleString()} FCFA`}
                        </span>
                      </div>

                      {isUnlocked ? (
                        <button
                          onClick={() => executeDownload(ex.title)}
                          className="px-4 py-2 bg-green-700/20 border border-green-500/40 hover:bg-green-700/40 text-[#4ade80] text-xs font-bold uppercase tracking-widest transition-all rounded-sm flex items-center gap-1 cursor-pointer"
                        >
                          <Download className="w-3.5 h-3.5" />
                          <span>MÉLODIE PRÊTE</span>
                        </button>
                      ) : (
                        <button
                          onClick={() => handleOpenPurchase(ex)}
                          className="px-4 py-2 bg-transparent text-gold border border-gold/40 hover:bg-gold hover:text-rich-black hover:border-gold transition-all duration-300 text-xs font-bold uppercase tracking-widest rounded-sm flex items-center gap-1.5 cursor-pointer"
                        >
                          <ShoppingBag className="w-3.5 h-3.5" />
                          <span>Acquérir</span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Dynamic notice */}
            <div className="border border-gold/10 p-5 rounded-sm bg-luxury-gray/40">
              <h4 className="text-xs font-mono text-[#C9A84C] uppercase mb-1 tracking-wider">Note sur la Protection Audiophile :</h4>
              <p className="text-[11px] text-gray-500 font-sans leading-relaxed">
                Les fichiers d'exclusivité téléchargés sont dotés d'un tatouage numérique imperceptible à l'oreille qui prouve votre qualité de Mécène Direct et vous authentifie en tant que propriétaire légal devant le label EMZ RECORD. 
              </p>
            </div>
          </div>

        </div>

      </div>

      {/* Dynamic Purchase Dialog */}
      <AnimatePresence>
        {isPurchaseModalOpen && selectedEx && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => { if (purchaseStep !== 'processing') setIsPurchaseModalOpen(false); }}
              className="absolute inset-0 bg-rich-black/80 backdrop-blur-md"
            />

            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 12 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 12 }}
              className="relative w-full max-w-md bg-luxury-gray border border-gold p-6 rounded-sm shadow-2xl z-10 overflow-hidden text-gray-200"
            >
              {purchaseStep !== 'processing' && (
                <button 
                  onClick={() => setIsPurchaseModalOpen(false)}
                  className="absolute top-4 right-4 text-gray-400 hover:text-gold transition-colors p-1"
                >
                  ✕
                </button>
              )}

              {/* Title Header */}
              <div className="mb-4">
                <span className="text-[10px] font-mono tracking-widest text-[#C9A84C] uppercase block mb-1">
                  ACHAT DIRECT EXCLUSIF
                </span>
                <h3 className="font-display text-xl text-white uppercase tracking-normal">
                  Fiche de Paiement Mobile
                </h3>
              </div>

              {purchaseStep === 'checkout' && (
                <form onSubmit={processPurchaseSimulation} className="space-y-4">
                  <div className="p-3 bg-rich-black border border-gold/10 rounded-sm flex gap-3 items-center">
                    <div className="w-12 h-12 bg-zinc-900 rounded overflow-hidden shrink-0">
                      <img src={selectedEx.image} alt={selectedEx.title} className="w-full h-full object-cover" />
                    </div>
                    <div>
                      <h4 className="text-xs font-sans font-bold text-white truncate max-w-[240px]">{selectedEx.title}</h4>
                      <p className="text-[10px] font-mono text-gold leading-none">{selectedEx.artist} • {selectedEx.type}</p>
                    </div>
                  </div>

                  <div className="flex flex-col">
                    <label className="text-[9px] uppercase tracking-wider text-gray-400 font-mono mb-1">
                      Nom Complet de l'Acquéreur d'Art *
                    </label>
                    <input 
                      type="text" 
                      required
                      value={buyerName}
                      onChange={(e) => setBuyerName(e.target.value)}
                      placeholder="Ex: Christian Kaboré"
                      className="px-3 py-2 bg-rich-black border border-gold/15 text-white placeholder-gray-600 focus:outline-none focus:border-gold transition-colors text-xs rounded-sm"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-[9px] uppercase tracking-wider text-gray-400 font-mono block">
                      Opérateur de Paiement Mobile Money (+226)
                    </label>
                    <div className="grid grid-cols-4 gap-2">
                      <button
                        type="button"
                        onClick={() => setPayingOperator('orange')}
                        className={`p-2 rounded-sm border text-center transition-all cursor-pointer ${
                          payingOperator === 'orange' ? 'border-[#FF6600] bg-[#FF6600]/10 text-white' : 'border-gold/10 bg-rich-black/20 text-gray-400'
                        }`}
                      >
                        <span className="font-sans text-[10px] font-bold">Orange</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setPayingOperator('moov')}
                        className={`p-2 rounded-sm border text-center transition-all cursor-pointer ${
                          payingOperator === 'moov' ? 'border-[#0081C4] bg-[#0081C4]/10 text-white' : 'border-gold/10 bg-rich-black/20 text-gray-400'
                        }`}
                      >
                        <span className="font-sans text-[10px] font-bold">Moov</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setPayingOperator('wave')}
                        className={`p-2 rounded-sm border text-center transition-all cursor-pointer ${
                          payingOperator === 'wave' ? 'border-[#1E90FF] bg-[#1E90FF]/10 text-white' : 'border-gold/10 bg-rich-black/20 text-gray-400'
                        }`}
                      >
                        <span className="font-sans text-[10px] font-bold">Wave BF</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setPayingOperator('card')}
                        className={`p-2 rounded-sm border text-center transition-all cursor-pointer ${
                          payingOperator === 'card' ? 'border-gold bg-gold/10 text-gold' : 'border-gold/10 bg-rich-black/20 text-gray-400'
                        }`}
                      >
                        <span className="font-sans text-[10px] font-bold">Carte</span>
                      </button>
                    </div>

                    {payingOperator !== 'card' && (
                      <div className="flex flex-col">
                        <label className="text-[9px] uppercase tracking-wider text-gray-400 font-mono mb-1">
                          Numéro Téléphone Mobile Money *
                        </label>
                        <input 
                          type="tel" 
                          required
                          value={buyerPhone}
                          onChange={(e) => setBuyerPhone(e.target.value)}
                          placeholder="Ex: +226 63 75 04 11"
                          className="px-3 py-2 bg-rich-black border border-gold/15 text-white placeholder-gray-600 focus:outline-none focus:border-gold transition-colors text-xs rounded-sm"
                        />
                      </div>
                    )}
                  </div>

                  <div className="pt-4 flex items-center justify-between border-t border-gold/15">
                    <div className="text-left">
                      <span className="text-[9px] font-mono text-gray-500 uppercase block leading-none">PRIX NET</span>
                      <span className="text-lg font-display text-white font-bold">{selectedEx.price.toLocaleString()} FCFA</span>
                    </div>
                    <button
                      type="submit"
                      className="px-5 py-2.5 bg-gold hover:bg-gold-hover text-rich-black text-xs uppercase tracking-widest font-bold rounded-sm transition-all cursor-pointer"
                    >
                      Payer et Débloquer
                    </button>
                  </div>
                </form>
              )}

              {/* SIMULATION */}
              {purchaseStep === 'processing' && (
                <div className="text-center py-6 space-y-4">
                  <div className="w-12 h-12 border-2 border-gold border-t-transparent rounded-full animate-spin mx-auto" />
                  <div className="space-y-1">
                    <h4 className="font-display text-md text-white tracking-widest uppercase">Autorisation en cours</h4>
                    <p className="text-[11px] text-gray-400 font-sans max-w-xs mx-auto">
                      Veuillez approuver la requête Push de <span className="text-white font-semibold">{selectedEx.price.toLocaleString()} FCFA</span> sur votre téléphone ou saisir le code PIN.
                    </p>
                  </div>
                  <div className="p-3 bg-rich-black/40 border border-gold/5 rounded text-[10px] font-mono text-gray-400 text-left max-w-xs mx-auto">
                    <div>MARCHAND: EMZ RECORD</div>
                    <div>ACHETEUR: {buyerName}</div>
                    <div>OPÉRATEUR: {payingOperator.toUpperCase()} MONEY</div>
                  </div>
                </div>
              )}

              {/* UNLOCKED / SUCCESS */}
              {purchaseStep === 'unlocked' && (
                <div className="text-center py-6 space-y-6">
                  <div className="w-12 h-12 bg-green-500/10 border border-green-500 rounded-full flex items-center justify-center mx-auto text-[#4ade80]">
                    <ShieldCheck className="w-7 h-7" />
                  </div>

                  <div className="space-y-1">
                    <h4 className="font-display text-lg text-white uppercase tracking-wider">Achat Royal Confirmé</h4>
                    <p className="text-xs text-gray-400 font-sans leading-relaxed">
                      L'œuvre numérique d'art direct <span className="text-white font-medium">{selectedEx.title}</span> a été liée à votre compte. Vous pouvez maintenant télécharger le fichier d'origine non compressé.
                    </p>
                  </div>

                  <div className="flex flex-col gap-2">
                    <button
                      onClick={() => executeDownload(selectedEx.title)}
                      className="py-3 bg-gold text-rich-black hover:bg-gold-hover uppercase tracking-widest font-bold text-xs rounded-sm transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Download className="w-4 h-4" />
                      <span>Télécharger le Fichier (WAV)</span>
                    </button>
                    
                    <button
                      onClick={() => setIsPurchaseModalOpen(false)}
                      className="text-[11px] text-gray-500 hover:text-white transition-colors py-1"
                    >
                      Retourner au Media Center
                    </button>
                  </div>
                </div>
              )}

            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Styled equalizer keyframe animations injection */}
      <style>{`
        @keyframes equalizer {
          0% {
            height: 3px;
          }
          100% {
            height: 100%;
          }
        }
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: rgba(0, 0, 0, 0.2);
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #C7A84C;
          border-radius: 2px;
        }
      `}</style>
    </section>
  );
}
