import React from 'react';

interface LogoProps {
  className?: string; // Optional class overriding sizing/margins
  color?: 'gold' | 'red' | 'white'; // Switch between brand or gold color setups
  showText?: boolean; // Whether to show 'RECORD' text underneath the claw marks
  iconOnly?: boolean; // If true, only render the claw emblem, smaller
}

export default function Logo({ className = '', color = 'red', showText = true, iconOnly = false }: LogoProps) {
  // Color configuration
  const stopColor1 = color === 'gold' ? '#FFEAB5' : color === 'white' ? '#FFFFFF' : '#8B0000'; // Dark Crimson inner shadow
  const stopColor2 = color === 'gold' ? '#C9A84C' : color === 'white' ? '#E8E8E8' : '#D2143A'; // Vivid Red peak highlights
  const stopColor3 = color === 'gold' ? '#8A6F27' : color === 'white' ? '#A3A3A3' : '#4A0404'; // Deep dark burgundy baseline
  
  const textColor = color === 'gold' ? 'text-gold' : color === 'white' ? 'text-white' : 'text-[#9B111E]';

  return (
    <div className={`flex flex-col items-center justify-center select-none ${className}`}>
      {/* SVG Claw emblem forming E-M-Z */}
      <svg 
        viewBox="0 0 1000 700" 
        className={`${iconOnly ? 'w-16 h-12' : 'w-full max-w-[280px] h-auto'} transition-all duration-300`}
        fill="url(#logo-grad)"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <linearGradient id="logo-grad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={stopColor1} />
            <stop offset="50%" stopColor={stopColor2} />
            <stop offset="100%" stopColor={stopColor3} />
          </linearGradient>
          <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="15" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        </defs>

        {/* --- E (3 horizontal jagged claw cuts) --- */}
        <g id="letter-E" className="transition-all duration-300">
          {/* Top Claw Scratch */}
          <path d="M 50 250 C 120 220, 220 220, 350 240 C 240 270, 140 275, 50 250 Z" />
          <path d="M 60 245 C 130 230, 210 240, 310 255 C 230 265, 130 260, 60 245 Z" opacity="0.6" fill="#000" />
          {/* Middle Claw Scratch */}
          <path d="M 50 360 C 130 330, 220 330, 340 350 C 240 380, 130 385, 50 360 Z" />
          <path d="M 60 355 C 120 345, 200 345, 300 360 C 220 375, 120 370, 60 355 Z" opacity="0.6" fill="#000" />
          {/* Bottom Claw Scratch */}
          <path d="M 60 480 C 140 450, 230 450, 350 470 C 250 500, 140 505, 60 480 Z" />
          <path d="M 70 475 C 130 465, 210 465, 310 480 C 230 495, 130 490, 70 475 Z" opacity="0.6" fill="#000" />
        </g>

        {/* --- M (4 vertical jagged organic scratches) --- */}
        <g id="letter-M" className="transition-all duration-300">
          {/* vertical claw 1 (Left-most) */}
          <path d="M 380 320 C 420 250, 420 450, 400 580 C 370 450, 360 250, 380 320 Z" />
          {/* vertical claw 2 */}
          <path d="M 440 250 C 490 180, 480 500, 460 640 C 430 500, 420 180, 440 250 Z" />
          {/* vertical claw 3 */}
          <path d="M 530 250 C 580 180, 570 500, 550 640 C 520 500, 510 180, 530 250 Z" />
          {/* vertical claw 4 (Right-most) */}
          <path d="M 600 320 C 640 250, 640 450, 620 580 C 590 450, 580 250, 600 320 Z" />
        </g>

        {/* --- Z (Dynamic sharp diagnostic scratch line cuts forming Z) --- */}
        <g id="letter-Z" className="transition-all duration-300">
          {/* Top Bar of Z */}
          <path d="M 660 260 C 740 230, 840 230, 930 250 C 830 280, 730 280, 660 260 Z" />
          {/* Diagonal scratch bar of Z */}
          <path d="M 910 260 L 680 550 C 740 530, 850 560, 940 540 C 820 500, 850 400, 910 260 Z" />
          {/* Bottom Bar of Z */}
          <path d="M 680 550 C 760 520, 850 530, 940 540 C 840 570, 740 570, 680 550 Z" />
        </g>
      </svg>

      {/* Styled futuristic spaced brand name from the original design */}
      {!iconOnly && showText && (
        <span 
          style={{ letterSpacing: '0.45em' }}
          className={`font-semibold uppercase text-center mt-2 pl-[0.45em] text-sm md:text-base tracking-[0.45em] transition-colors duration-300 ${textColor}`}
        >
          R E C O R D
        </span>
      )}
    </div>
  );
}
