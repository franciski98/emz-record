import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ROSTER } from '../data';
import { Artist } from '../types';
import { Youtube, Instagram, Disc, Play, X, User } from 'lucide-react';

export default function Roster() {
  const [selectedArtist, setSelectedArtist] = useState<Artist | null>(null);

  return (
    <section id="roster" className="py-24 bg-luxury-gray relative">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] bg-gold/5 blur-[120px] rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <div className="mb-16">
          <span className="text-xs uppercase tracking-[0.3em] text-gold font-sans font-medium block mb-2">
            La Sagesse & Le Talent
          </span>
          <h2 className="font-display text-5xl md:text-6xl tracking-wide uppercase text-white">
            Le Roster <span className="gold-gradient-text font-light">Prestige</span>
          </h2>
          <div className="w-16 h-[2px] bg-gold mt-4" />
        </div>

        {/* Dynamic Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {ROSTER.map((artist, idx) => (
            <motion.div
              key={artist.id}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: idx * 0.1 }}
              className="group relative h-[450px] w-full bg-rich-black rounded-xl overflow-hidden shadow-lg border border-gold/15 transition-all duration-300 hover:border-gold/40 flex flex-col cursor-pointer"
              onClick={() => setSelectedArtist(artist)}
            >
              {/* Image Container with zoom shift inside */}
              <div className="relative w-full h-[320px] overflow-hidden">
                <img
                  src={artist.image}
                  alt={artist.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover grayscale group-hover:grayscale-0 group-hover:scale-110 transition-all duration-500 ease-out"
                />

                {/* Shimmer / Shadow cover overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-rich-black via-transparent to-transparent opacity-90" />

                {/* Overlap streaming icons revealing state with a transition of 0.3s */}
                <div className="absolute inset-0 flex items-center justify-center gap-4 bg-rich-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 backdrop-blur-sm">
                  {artist.streamingLinks.spotify && (
                    <a
                      href={artist.streamingLinks.spotify}
                      target="_blank"
                      referrerPolicy="no-referrer"
                      rel="noopener noreferrer"
                      className="p-3 bg-gold hover:bg-white text-rich-black rounded-full transition-colors duration-200"
                      onClick={(e) => e.stopPropagation()}
                      title="Écouter sur Spotify"
                    >
                      <Disc className="w-5 h-5 animate-[spin_6s_linear_infinite]" />
                    </a>
                  )}
                  {artist.streamingLinks.appleMusic && (
                    <a
                      href={artist.streamingLinks.appleMusic}
                      target="_blank"
                      referrerPolicy="no-referrer"
                      rel="noopener noreferrer"
                      className="p-3 bg-gold hover:bg-white text-rich-black rounded-full transition-colors duration-200"
                      onClick={(e) => e.stopPropagation()}
                      title="Écouter sur Apple Music"
                    >
                      <Play className="w-5 h-5 fill-rich-black" />
                    </a>
                  )}
                  {artist.streamingLinks.youtube && (
                    <a
                      href={artist.streamingLinks.youtube}
                      target="_blank"
                      referrerPolicy="no-referrer"
                      rel="noopener noreferrer"
                      className="p-3 bg-gold hover:bg-white text-rich-black rounded-full transition-colors duration-200"
                      onClick={(e) => e.stopPropagation()}
                      title="Vidéos YouTube"
                    >
                      <Youtube className="w-5 h-5" />
                    </a>
                  )}
                  {artist.streamingLinks.instagram && (
                    <a
                      href={artist.streamingLinks.instagram}
                      target="_blank"
                      referrerPolicy="no-referrer"
                      rel="noopener noreferrer"
                      className="p-3 bg-gold hover:bg-white text-rich-black rounded-full transition-colors duration-200"
                      onClick={(e) => e.stopPropagation()}
                      title="Suivre sur Instagram"
                    >
                      <Instagram className="w-5 h-5" />
                    </a>
                  )}
                </div>
              </div>

              {/* Text metadata block at bottom */}
              <div className="p-6 mt-auto flex flex-col justify-end relative bg-rich-black z-10 border-t border-gold/5 group-hover:bg-gold/5 transition-all duration-300 h-[130px]">
                <span className="text-[10px] uppercase tracking-widest text-[#C9A84C] font-mono leading-none mb-2 block">
                  {artist.role}
                </span>
                <h3 className="font-display text-2xl tracking-wide text-white group-hover:text-gold transition-colors leading-none">
                  {artist.name}
                </h3>
                <span className="text-xs text-gray-500 font-sans mt-3 group-hover:text-gray-400 flex items-center gap-1">
                  <User className="w-3.5 h-3.5" />
                  Cliquez pour voir la bio
                </span>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Roster Bio Slide Drawer Details */}
      <AnimatePresence>
        {selectedArtist && (
          <div className="fixed inset-0 z-50 flex items-center justify-end bg-rich-black/85 backdrop-blur-sm p-4">
            <motion.div
              initial={{ x: '100%', opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: '100%', opacity: 0 }}
              transition={{ type: 'spring', damping: 25, stiffness: 120 }}
              className="relative w-full max-w-lg h-full max-h-[95vh] overflow-y-auto glass-card border border-gold/20 p-8 md:p-12 flex flex-col rounded-sm shadow-[0_0_50px_rgba(0,0,0,0.8)]"
            >
              <button
                onClick={() => setSelectedArtist(null)}
                className="absolute top-6 right-6 text-gray-400 hover:text-gold transition-colors p-2 z-10 bg-rich-black/80 rounded-full"
                aria-label="Fermer"
              >
                <X className="w-6 h-6" />
              </button>

              <div className="flex-1 mt-6">
                {/* Hero Artist Photo */}
                <div className="aspect-[4/5] w-full rounded-sm overflow-hidden mb-8 border border-gold/15">
                  <img
                    src={selectedArtist.image}
                    alt={selectedArtist.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </div>

                {/* Metal descriptions */}
                <span className="text-xs font-mono uppercase tracking-widest text-[#C9A84C] block mb-2">
                  {selectedArtist.role}
                </span>
                <h2 className="font-display text-4xl text-white tracking-wide mb-6">
                  {selectedArtist.name}
                </h2>

                <p className="text-gray-300 font-sans font-light leading-relaxed text-sm md:text-base mb-8">
                  {selectedArtist.bio}
                </p>

                {/* Platforms summary link list */}
                <div className="border-t border-gold/15 pt-6">
                  <h4 className="text-xs uppercase tracking-widest text-gold font-sans font-bold mb-4">
                    Suivre sur les réseaux
                  </h4>
                  <div className="flex gap-4">
                    {selectedArtist.streamingLinks.spotify && (
                      <a
                        href={selectedArtist.streamingLinks.spotify}
                        target="_blank"
                        referrerPolicy="no-referrer"
                        rel="noreferrer"
                        className="px-4 py-2 bg-rich-black/80 rounded-sm border border-gold/20 text-xs text-gray-300 hover:text-gold hover:border-gold transition-colors block uppercase tracking-wider text-center flex-1"
                      >
                        Spotify
                      </a>
                    )}
                    {selectedArtist.streamingLinks.youtube && (
                      <a
                        href={selectedArtist.streamingLinks.youtube}
                        target="_blank"
                        referrerPolicy="no-referrer"
                        rel="noreferrer"
                        className="px-4 py-2 bg-rich-black/80 rounded-sm border border-gold/20 text-xs text-gray-300 hover:text-gold hover:border-gold transition-colors block uppercase tracking-wider text-center flex-1"
                      >
                        YouTube
                      </a>
                    )}
                    {selectedArtist.streamingLinks.instagram && (
                      <a
                        href={selectedArtist.streamingLinks.instagram}
                        target="_blank"
                        referrerPolicy="no-referrer"
                        rel="noreferrer"
                        className="px-4 py-2 bg-rich-black/80 rounded-sm border border-gold/20 text-xs text-gray-300 hover:text-gold hover:border-gold transition-colors block uppercase tracking-wider text-center flex-1"
                      >
                        Instagram
                      </a>
                    )}
                  </div>
                </div>
              </div>

              <div className="mt-8 pt-6 border-t border-gold/10">
                <button
                  onClick={() => setSelectedArtist(null)}
                  className="w-full py-3 bg-gold hover:bg-gold-hover text-rich-black text-xs font-sans uppercase font-bold tracking-widest transition-colors rounded-sm"
                >
                  Fermer la biographie
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}
