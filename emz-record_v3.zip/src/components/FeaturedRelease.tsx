import { motion } from 'motion/react';
import { Play, Disc, Music, ExternalLink } from 'lucide-react';
import { FEATURED_RELEASE } from '../data';

export default function FeaturedRelease() {
  return (
    <section id="releases" className="py-24 bg-luxury-gray relative overflow-hidden">
      {/* Background glow shadow */}
      <div className="absolute bottom-10 left-10 w-[300px] h-[300px] bg-gold/5 blur-[120px] rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6">
        {/* Section Title Header */}
        <div className="mb-16">
          <span className="text-xs uppercase tracking-[0.3em] text-gold font-sans font-medium block mb-2">
            La Révélation Sonore
          </span>
          <h2 className="font-display text-5xl md:text-6xl tracking-wide uppercase text-white">
            Featured <span className="gold-gradient-text font-light">Release</span>
          </h2>
          <div className="w-16 h-[2px] bg-gold mt-4" />
        </div>

        {/* Asymmetric Content Layout Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Block: Description (Length - 5 columns) */}
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="lg:col-span-5 flex flex-col justify-center"
          >
            <div className="inline-flex items-center gap-2 mb-4">
              <span className="text-xs font-sans tracking-widest text-[#FFEAB5] bg-gold/15 px-3 py-1 rounded-sm uppercase">
                Sortie Officielle
              </span>
              <span className="text-sm text-gray-500 font-mono">
                {FEATURED_RELEASE.releaseDate}
              </span>
            </div>

            <h3 className="font-display text-4xl sm:text-5xl text-white tracking-wide mb-2">
              {FEATURED_RELEASE.title}
            </h3>
            <p className="font-sans font-medium text-gold tracking-widest text-sm mb-6 uppercase">
              {FEATURED_RELEASE.artist}
            </p>

            <p className="text-gray-400 font-sans font-light leading-relaxed mb-8">
              {FEATURED_RELEASE.description}
            </p>

            {/* Elite Streaming Options Panel */}
            <div className="border-t border-gold/10 pt-6">
              <h4 className="text-xs tracking-widest font-sans font-semibold text-gray-400 uppercase mb-4 flex items-center gap-2">
                <Disc className="w-4 h-4 text-gold animate-[spin_4s_linear_infinite]" />
                Écouter sur les plateformes élite
              </h4>
              
              <div className="flex flex-wrap gap-4">
                <a
                  href={FEATURED_RELEASE.streamingLinks.spotify}
                  target="_blank"
                  referrerPolicy="no-referrer"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 px-4 py-2.5 bg-rich-black/60 hover:bg-gold hover:text-rich-black text-gray-300 rounded-sm border border-gold/20 hover:border-gold transition-all duration-300 text-xs tracking-wider uppercase font-sans font-medium"
                >
                  <Music className="w-3.5 h-3.5" />
                  Spotify
                </a>
                <a
                  href={FEATURED_RELEASE.streamingLinks.appleMusic}
                  target="_blank"
                  referrerPolicy="no-referrer"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 px-4 py-2.5 bg-rich-black/60 hover:bg-gold hover:text-rich-black text-gray-300 rounded-sm border border-gold/20 hover:border-gold transition-all duration-300 text-xs tracking-wider uppercase font-sans font-medium"
                >
                  <Play className="w-3.5 h-3.5" />
                  Apple Music
                </a>
              </div>
            </div>
          </motion.div>

          {/* Right Block: Integrated Styled YouTube Player (Length - 7 columns) */}
          <motion.div 
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="lg:col-span-7"
          >
            {/* YouTube Container with rounded corners & glorious gold shadow */}
            <div className="relative aspect-video w-full rounded-2xl overflow-hidden glass-card border border-gold/30 shadow-[0_10px_40px_rgba(201,168,76,0.18)] group">
              
              {/* YouTube IFrame Embed (Actual interactive component) */}
              <iframe
                src={`https://www.youtube.com/embed/${FEATURED_RELEASE.youtubeId}?autoplay=0&hl=fr&modestbranding=1&rel=0`}
                title={`${FEATURED_RELEASE.title} Video Player`}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                className="absolute inset-0 w-full h-full object-cover z-10"
              />

              {/* Decorative light shimmer overlay on frame wrapper border */}
              <div className="absolute inset-0 border border-gold/20 rounded-2xl pointer-events-none z-20 pointer-none group-hover:border-gold/40 transition-colors duration-500" />
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
