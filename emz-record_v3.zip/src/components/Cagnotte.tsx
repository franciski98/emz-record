import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Heart, Coins, Users, TrendingUp, Award, ArrowRight, ShieldCheck, CheckCircle2, User, Landmark, HelpCircle, AlertCircle } from 'lucide-react';
import { ROSTER } from '../data';

interface Campaign {
  id: string;
  artistId: string;
  artistName: string;
  projectName: string;
  description: string;
  target: number;
  current: number;
  backersCount: number;
  daysLeft: number;
  image: string;
}

interface Contribution {
  backerName: string;
  amount: number;
  message?: string;
  timestamp: string;
  tier: string;
}

export default function Cagnotte() {
  const [campaigns, setCampaigns] = useState<Campaign[]>([
    {
      id: "camp-salby",
      artistId: "salby",
      artistName: "SALBY",
      projectName: "Tournée Ouest-Africaine 'Cœur Vaillant'",
      description: "Financement des décors scéniques d'or, musiciens en live et système d'éclairage immersif pour la première tournée de festivals de Salby.",
      target: 3000000,
      current: 2150000,
      backersCount: 68,
      daysLeft: 15,
      image: ROSTER.find(a => a.id === "salby")?.image || ""
    },
    {
      id: "camp-lima",
      artistId: "lima",
      artistName: "LIMA",
      projectName: "Concert Symphonique 'Stade du 4-Août'",
      description: "Organisation du méga-concert événement réunissant 50 choristes traditionnels et chorégraphes d'exception pour un show historique.",
      target: 5000000,
      current: 3820000,
      backersCount: 94,
      daysLeft: 22,
      image: ROSTER.find(a => a.id === "lima")?.image || ""
    },
    {
      id: "camp-josby",
      artistId: "josby",
      artistName: "JOSBY",
      projectName: "Visual Album Trap 'Écarlate'",
      description: "Tournage de 5 clips interconnectés en format cinéma 4K avec cascades, effets pyrotechniques et stylisme haute couture rouge et or.",
      target: 2000000,
      current: 1420000,
      backersCount: 39,
      daysLeft: 19,
      image: ROSTER.find(a => a.id === "josby")?.image || ""
    },
    {
      id: "camp-bandita",
      artistId: "el-bandita",
      artistName: "EL BANDITA",
      projectName: "Documentaire 'La Voix Noble de la Rue'",
      description: "Création d'un film documentaire poignant retraçant le parcours d'El Bandita et la confection artisanale de ses tenues Faso Danfani.",
      target: 1800000,
      current: 980000,
      backersCount: 27,
      daysLeft: 10,
      image: ROSTER.find(a => a.id === "el-bandita")?.image || ""
    },
    {
      id: "camp-flowman",
      artistId: "flowman-boy",
      artistName: "FLOWMAN BOY",
      projectName: "Album Symphonique 'Aura de Plume'",
      description: "L'enregistrement d'une œuvre majeure fusionnant l'Afro-Vibe avec un orchestre philharmonique de 24 musiciens traditionnels et classiques.",
      target: 2500000,
      current: 1680000,
      backersCount: 42,
      daysLeft: 18,
      image: ROSTER.find(a => a.id === "flowman-boy")?.image || ""
    },
    {
      id: "camp-kosa",
      artistId: "kosa-pic",
      artistName: "KOSA PIC",
      projectName: "Collection Couture 'Vibrations d'Or'",
      description: "Conception et fabrication de dix tenues d'apparat exclusives mêlant jacquards d'or, faso danfani d'exception et velours d'Italie pour la prochaine tournée.",
      target: 4000000,
      current: 2950000,
      backersCount: 57,
      daysLeft: 24,
      image: ROSTER.find(a => a.id === "kosa-pic")?.image || ""
    },
    {
      id: "camp-djo",
      artistId: "djo-le-rapide",
      artistName: "DJO LE RAPIDE",
      projectName: "Clip Cinématographique 'Chessboard Master'",
      description: "Un court-métrage musical au scénario soigné et à l'esthétique ultra-léchée, filmé à Bobo-Dioulasso et dans les ruines de Loropéni.",
      target: 1500000,
      current: 450000,
      backersCount: 14,
      daysLeft: 12,
      image: ROSTER.find(a => a.id === "djo-le-rapide")?.image || ""
    }
  ]);

  const [selectedCampaign, setSelectedCampaign] = useState<Campaign | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [backerName, setBackerName] = useState('');
  const [backerMessage, setBackerMessage] = useState('');
  const [selectedTier, setSelectedTier] = useState<'bronze' | 'argent' | 'or' | 'custom'>('bronze');
  const [customAmount, setCustomAmount] = useState('10000');
  const [paymentMethod, setPaymentMethod] = useState<'orange' | 'moov' | 'wave' | 'card'>('orange');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentStep, setPaymentStep] = useState<'details' | 'simulation' | 'success'>('details');

  // Interactive contribution list simulating a live feed 
  const [contributions, setContributions] = useState<Record<string, Contribution[]>>({
    "camp-salby": [
      { backerName: "Rasmané Ouédraogo", amount: 150000, message: "Salby notre fierté nationale !", timestamp: "Il y a 1 heure", tier: "Mécène Or" },
      { backerName: "Mariam Sankara", amount: 25000, message: "En avant pour le concert d'or !", timestamp: "Il y a 3 heures", tier: "Mécène Argent" }
    ],
    "camp-lima": [
      { backerName: "Aminata Traoré", amount: 200000, message: "La reine du stade mérite le meilleur !", timestamp: "Il y a 2 heures", tier: "Mécène Or" },
      { backerName: "Kader Sanou", amount: 50000, message: "Voix d'or pure !", timestamp: "Il y a 6 heures", tier: "Mécène Argent" }
    ],
    "camp-josby": [
      { backerName: "Idrissa Barry", amount: 75000, message: "Le bandana rouge au sommet !", timestamp: "Il y a 4 heures", tier: "Mécène Argent" }
    ],
    "camp-bandita": [
      { backerName: "Bouba Compaoré", amount: 50000, message: "Toujours avec la rue noble !", timestamp: "Il y a 5 heures", tier: "Mécène Argent" }
    ],
    "camp-flowman": [
      { backerName: "Oumar Traoré", amount: 100000, message: "Pour la grandeur de notre musique !", timestamp: "Il y a 3 heures", tier: "Mécène Or" },
      { backerName: "Awa Dembélé", amount: 25000, message: "Hâte d'entendre la harpe traditionnelle de luxe !", timestamp: "Il y a un jour", tier: "Mécène Argent" }
    ],
    "camp-kosa": [
      { backerName: "Zalissa Kaboré", amount: 250000, message: "Kosa Pic est une icône de la mode. Le Faso Danfani mérite l'or !", timestamp: "Il y a 4 heures", tier: "Mécène Or" },
      { backerName: "Fabrice Somé", amount: 5000, message: "Force à toi l'artiste !", timestamp: "Il y a 2 jours", tier: "Mécène Bronze" }
    ],
    "camp-djo": [
      { backerName: "Dr. Diallo", amount: 50000, message: "Le rap d'élite mérite un écrin de cinéma.", timestamp: "Il y a 5 heures", tier: "Mécène Argent" }
    ]
  });

  const getTierInfo = () => {
    switch (selectedTier) {
      case 'bronze':
        return { amount: 5000, label: "Mécène Bronze", perk: "Nom affiché d'Or sur le tableau d'honneur des contributeurs." };
      case 'argent':
        return { amount: 25000, label: "Mécène Argent", perk: "Accès anticipé exclusif à la maquette audio haute fidélité WAV." };
      case 'or':
        return { amount: 100000, label: "Mécène Or", perk: "Invitation privée VIP d'écoute de prestige au Studio 'Aura Or'." };
      case 'custom':
        const parsed = parseInt(customAmount) || 2000;
        return {
          amount: parsed,
          label: parsed >= 100000 ? "Grand Mécène d'Élite" : parsed >= 25000 ? "Mécène Argent" : "Mécène Bronze",
          perk: parsed >= 100000 ? "Privilèges totaux (Studio VIP + Vinyle numéroté en édition de luxe + Crédits dans l'œuvre)." : "Inclusion et remerciements gravés au cœur du projet."
        };
    }
  };

  const handleOpenContribution = (campaign: Campaign) => {
    setSelectedCampaign(campaign);
    setPaymentStep('details');
    setIsModalOpen(true);
    setBackerName('');
    setBackerMessage('');
    setSelectedTier('bronze');
    setPhoneNumber('');
  };

  const startSimulation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!backerName.trim()) {
      alert("S'il vous plaît, saisissez votre nom ou pseudonyme de mécène.");
      return;
    }
    if ((paymentMethod === 'orange' || paymentMethod === 'moov' || paymentMethod === 'wave') && !phoneNumber.trim()) {
      alert("Veuillez entrer votre numéro de Mobile Money.");
      return;
    }
    setPaymentStep('simulation');
  };

  const confirmPaymentSimulation = () => {
    setIsProcessing(true);
    const tierInfo = getTierInfo();

    // Simulate luxury verification
    setTimeout(() => {
      setIsProcessing(false);
      setPaymentStep('success');

      // Update campaign details
      if (selectedCampaign) {
        setCampaigns(prevCampaigns =>
          prevCampaigns.map(c =>
            c.id === selectedCampaign.id
              ? {
                  ...c,
                  current: c.current + tierInfo.amount,
                  backersCount: c.backersCount + 1
                }
              : c
          )
        );

        // Add to live honors feed
        const newContr: Contribution = {
          backerName: backerName.trim(),
          amount: tierInfo.amount,
          message: backerMessage.trim() || undefined,
          timestamp: "À l'instant",
          tier: tierInfo.label
        };

        setContributions(prev => ({
          ...prev,
          [selectedCampaign.id]: [newContr, ...(prev[selectedCampaign.id] || [])]
        }));
      }
    }, 2500);
  };

  return (
    <section id="mece-cagnotte" className="py-24 bg-rich-black relative border-t border-gold/10">
      <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_30%_20%,rgba(199,168,76,0.03),transparent_60%)] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6">
        
        {/* Section Header */}
        <div className="mb-16 flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div>
            <span className="text-xs uppercase tracking-[0.3em] text-gold font-sans font-medium block mb-2">
              Action Solidaire & Mécénat d'Élite
            </span>
            <h2 className="font-display text-4xl md:text-5xl tracking-wide uppercase text-white">
              Soutenir le <span className="gold-gradient-text font-light">Roster</span>
            </h2>
            <div className="w-16 h-[2px] bg-gold mt-4" />
          </div>
          <p className="text-gray-400 font-sans font-light text-sm max-w-md leading-relaxed">
            Financez directement les œuvres les plus prestigieuses et ambitieuses du label. En tant que Mécène d'Honneur d'EMZ RECORD, vous écrivez l'histoire à nos côtés et bénéficiez de récompenses uniques.
          </p>
        </div>

        {/* Campaigns Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {campaigns.map((camp) => {
            const percentage = Math.min(100, Math.round((camp.current / camp.target) * 100));
            return (
              <div 
                key={camp.id} 
                className="bg-luxury-gray border border-gold/10 hover:border-gold/30 rounded-sm overflow-hidden flex flex-col justify-between transition-all duration-300 group"
              >
                {/* Campaign Image Header */}
                <div className="relative h-48 overflow-hidden bg-zinc-900">
                  <img 
                    src={camp.image} 
                    alt={camp.projectName} 
                    className="w-full h-full object-cover grayscale brightness-90 group-hover:grayscale-0 group-hover:scale-105 transition-all duration-700"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-luxury-gray via-luxury-gray/40 to-transparent" />
                  <span className="absolute top-4 left-4 bg-gold/90 text-rich-black text-[9px] uppercase tracking-widest font-mono font-bold px-2 py-1 rounded-sm">
                    {camp.artistName}
                  </span>
                  <span className="absolute bottom-4 right-4 text-xs font-mono text-gold flex items-center gap-1.5 bg-rich-black/60 px-2 py-1 rounded-sm border border-gold/10">
                    <TrendingUp className="w-3.5 h-3.5" />
                    <span>{percentage}% financé</span>
                  </span>
                </div>

                {/* Body Details */}
                <div className="p-6 flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className="font-display text-xl text-[#FFEAB5] tracking-wide mb-2 group-hover:text-gold transition-colors">
                      {camp.projectName}
                    </h3>
                    <p className="text-gray-400 font-sans font-light text-xs leading-relaxed mb-6">
                      {camp.description}
                    </p>
                  </div>

                  {/* Meter Metric Bar */}
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between text-xs font-mono text-gray-500 mb-1.5">
                        <span>{camp.current.toLocaleString()} FCFA récoltés</span>
                        <span>Objectif: {camp.target.toLocaleString()} FCFA</span>
                      </div>
                      <div className="w-full h-1.5 bg-rich-black rounded-full overflow-hidden p-[1px] border border-gold/5">
                        <motion.div 
                          initial={{ width: 0 }}
                          whileInView={{ width: `${percentage}%` }}
                          viewport={{ once: true }}
                          className="h-full bg-gradient-to-r from-gold to-[#FFEAB5] rounded-full"
                          transition={{ duration: 1.2, ease: "easeOut" }}
                        />
                      </div>
                    </div>

                    {/* Meta Info footer */}
                    <div className="grid grid-cols-3 gap-2 border-t border-gold/5 pt-4 text-center">
                      <div>
                        <span className="block text-[10px] text-gray-500 uppercase tracking-widest font-mono">Mécènes</span>
                        <span className="font-sans font-medium text-white text-sm">{camp.backersCount}</span>
                      </div>
                      <div className="border-x border-gold/5">
                        <span className="block text-[10px] text-gray-500 uppercase tracking-widest font-mono">Restants</span>
                        <span className="font-sans font-medium text-white text-sm">{camp.daysLeft}j</span>
                      </div>
                      <div>
                        <span className="block text-[10px] text-gray-500 uppercase tracking-widest font-mono">Impact</span>
                        <span className="font-sans font-medium text-gold text-sm uppercase text-[9px] tracking-wider">PRESTIGE</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Action Rows */}
                <div className="p-6 border-t border-gold/5 bg-rich-black/30 flex items-center justify-between gap-4">
                  <div className="max-w-[55%]">
                    <span className="text-[9px] font-mono text-gray-500 uppercase block">Dernier mécène</span>
                    <span className="text-xs text-gray-300 font-sans font-medium truncate block">
                      {contributions[camp.id]?.[0]?.backerName || "Soyez le premier !"}
                    </span>
                  </div>
                  <button
                    onClick={() => handleOpenContribution(camp)}
                    className="px-4 py-2 text-xs uppercase tracking-widest font-bold bg-transparent text-gold border border-gold/40 hover:bg-gold hover:text-rich-black hover:border-gold transition-all duration-300 rounded-sm flex items-center gap-1.5 cursor-pointer shrink-0"
                  >
                    <span>Soutenir</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Live Honors Board */}
        <div className="mt-16 border border-gold/10 p-8 rounded-sm bg-luxury-gray/40 backdrop-blur-md">
          <div className="flex items-center gap-2 mb-6">
            <Award className="w-5 h-5 text-gold" />
            <h3 className="font-display text-xl text-white tracking-widest uppercase">
              Tableau des Mécènes d'Honneur de la Maison
            </h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {campaigns.map(camp => (
              <div key={camp.id} className="space-y-4">
                <span className="text-[10px] font-mono tracking-widest text-gold text-gold/80 block uppercase border-b border-gold/10 pb-1.5">
                  Projet {camp.artistName}
                </span>
                <div className="space-y-3 max-h-[220px] overflow-y-auto pr-2 custom-scrollbar">
                  {(contributions[camp.id] || []).map((c, i) => (
                    <div key={i} className="p-3 bg-rich-black/40 border border-gold/5 rounded-sm hover:border-gold/10 transition-colors">
                      <div className="flex justify-between items-start gap-2">
                        <span className="text-xs font-sans font-bold text-white shrink-0">
                          {c.backerName}
                        </span>
                        <span className="text-[10px] font-mono text-gold shrink-0">
                          +{c.amount.toLocaleString()} FCFA
                        </span>
                      </div>
                      <span className="text-[9px] font-mono text-gray-500 block uppercase mb-1">{c.tier} • {c.timestamp}</span>
                      {c.message && (
                        <p className="text-[11px] text-gray-400 font-sans font-light italic leading-relaxed mt-1">
                          "{c.message}"
                        </p>
                      )}
                    </div>
                  ))}
                  {(!contributions[camp.id] || contributions[camp.id].length === 0) && (
                    <span className="text-xs text-gray-500 italic block py-2">Aucun mécène à cette heure.</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* Contribution and Payment Modal */}
      <AnimatePresence>
        {isModalOpen && selectedCampaign && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => { if (!isProcessing) setIsModalOpen(false); }}
              className="absolute inset-0 bg-rich-black/80 backdrop-blur-md"
            />

            {/* Modal Body */}
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="relative w-full max-w-xl bg-luxury-gray border border-gold p-6 md:p-8 rounded-sm shadow-2xl z-10 overflow-hidden text-gray-200"
            >
              {/* Closing Button */}
              {!isProcessing && (
                <button 
                  onClick={() => setIsModalOpen(false)}
                  className="absolute top-4 right-4 text-gray-400 hover:text-gold transition-colors p-1"
                >
                  ✕
                </button>
              )}

              {/* Title Section */}
              <div className="mb-6">
                <span className="text-[10px] font-mono tracking-widest text-[#C9A84C] uppercase block mb-1">
                  MÉCÉNAT ACTIF • {selectedCampaign.artistName}
                </span>
                <h3 className="font-display text-2xl text-white uppercase tracking-wide">
                  Soutenir: {selectedCampaign.projectName}
                </h3>
              </div>

              {/* STAGES */}
              {paymentStep === 'details' && (
                <form onSubmit={startSimulation} className="space-y-5">
                  
                  {/* Contributor credentials */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex flex-col">
                      <label className="text-[10px] uppercase tracking-wider text-gray-400 font-mono mb-1.5">
                        Nom ou Pseudonyme du Mécène *
                      </label>
                      <input 
                        type="text" 
                        required
                        value={backerName}
                        onChange={(e) => setBackerName(e.target.value)}
                        placeholder="Ex: Alassane Ouedraogo"
                        className="px-3 py-2.5 bg-rich-black border border-gold/15 text-white placeholder-gray-600 focus:outline-none focus:border-gold transition-colors text-xs rounded-sm"
                      />
                    </div>
                    <div className="flex flex-col">
                      <label className="text-[10px] uppercase tracking-wider text-gray-400 font-mono mb-1.5">
                        Message d'Encouragement (Optionnel)
                      </label>
                      <input 
                        type="text" 
                        value={backerMessage}
                        onChange={(e) => setBackerMessage(e.target.value)}
                        placeholder="Ex: Force à toi pour la suite !"
                        className="px-3 py-2.5 bg-rich-black border border-gold/15 text-white placeholder-gray-600 focus:outline-none focus:border-gold transition-colors text-xs rounded-sm"
                      />
                    </div>
                  </div>

                  {/* Level selection */}
                  <div>
                    <label className="text-[10px] uppercase tracking-wider text-gray-400 font-mono block mb-2">
                      Choisissez votre Palier de Soutien
                    </label>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                      {/* Bronze */}
                      <button
                        type="button"
                        onClick={() => setSelectedTier('bronze')}
                        className={`p-3 rounded-sm border text-left flex flex-col justify-between transition-all cursor-pointer ${
                          selectedTier === 'bronze' ? 'bg-gold/10 border-gold' : 'bg-rich-black/40 border-gold/10 hover:border-gold/35'
                        }`}
                      >
                        <span className="text-[9px] font-mono text-gray-500 uppercase">PALIER BRONZE</span>
                        <span className="font-sans font-bold text-sm text-white mt-1">5 000 FCFA</span>
                      </button>

                      {/* Silver */}
                      <button
                        type="button"
                        onClick={() => setSelectedTier('argent')}
                        className={`p-3 rounded-sm border text-left flex flex-col justify-between transition-all cursor-pointer ${
                          selectedTier === 'argent' ? 'bg-gold/10 border-gold' : 'bg-rich-black/40 border-gold/10 hover:border-gold/35'
                        }`}
                      >
                        <span className="text-[9px] font-mono text-gray-500 uppercase">PALIER ARGENT</span>
                        <span className="font-sans font-bold text-sm text-gold mt-1">25 000 FCFA</span>
                      </button>

                      {/* Gold */}
                      <button
                        type="button"
                        onClick={() => setSelectedTier('or')}
                        className={`p-3 rounded-sm border text-left flex flex-col justify-between transition-all cursor-pointer ${
                          selectedTier === 'or' ? 'bg-gold/10 border-gold' : 'bg-rich-black/40 border-gold/10 hover:border-gold/35'
                        }`}
                      >
                        <span className="text-[9px] font-mono text-gold/80 uppercase">PALIER OR</span>
                        <span className="font-sans font-bold text-sm text-[#FFEAB5] mt-1">100 000 FCFA</span>
                      </button>
                    </div>

                    {/* Custom option */}
                    <div className="mt-3">
                      <button
                        type="button"
                        onClick={() => setSelectedTier('custom')}
                        className={`w-full p-2.5 rounded-sm border text-left flex justify-between items-center transition-all cursor-pointer text-xs ${
                          selectedTier === 'custom' ? 'bg-gold/10 border-gold' : 'bg-rich-black/40 border-gold/10 hover:border-gold/35'
                        }`}
                      >
                        <span className="font-mono text-gray-400 uppercase text-[9px]">Soutenir d'un Montant Libre</span>
                        <span className="font-sans font-bold text-gold">Saisie Libre</span>
                      </button>
                      
                      {selectedTier === 'custom' && (
                        <div className="mt-2 text-right">
                          <div className="relative inline-block w-48">
                            <input 
                              type="number" 
                              min="1000"
                              value={customAmount}
                              onChange={(e) => setCustomAmount(e.target.value)}
                              className="w-full pl-3 pr-16 py-2 bg-rich-black border border-gold text-right text-white font-sans text-xs focus:outline-none focus:ring-0 rounded-sm"
                            />
                            <span className="absolute right-3 top-2 text-[9px] font-mono text-gold uppercase">FCFA</span>
                          </div>
                          <span className="block text-[9px] text-gray-500 mt-1 italic">Contribution minimum : 1 000 FCFA</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Level benefits box */}
                  <div className="p-3 bg-rich-black/60 border border-gold/10 rounded-sm">
                    <span className="text-[9px] font-mono text-gold uppercase block tracking-wider mb-0.5">Avantages du Grade {getTierInfo().label} :</span>
                    <p className="text-[11px] text-gray-400 font-sans leading-relaxed">
                      {getTierInfo().perk}
                    </p>
                  </div>

                  {/* Payment selection & number */}
                  <div className="space-y-3">
                    <label className="text-[10px] uppercase tracking-wider text-gray-400 font-mono block">
                      Opérateur de Paiement Élite
                    </label>
                    <div className="grid grid-cols-4 gap-2">
                      <button
                        type="button"
                        onClick={() => setPaymentMethod('orange')}
                        className={`p-2 rounded-sm border text-center transition-all cursor-pointer ${
                          paymentMethod === 'orange' ? 'border-[#FF6600] bg-[#FF6600]/10 text-white' : 'border-gold/10 bg-rich-black/20 text-gray-400'
                        }`}
                      >
                        <span className="font-sans text-[11px] font-bold">Orange Money</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setPaymentMethod('moov')}
                        className={`p-2 rounded-sm border text-center transition-all cursor-pointer ${
                          paymentMethod === 'moov' ? 'border-[#0081C4] bg-[#0081C4]/10 text-white' : 'border-gold/10 bg-rich-black/20 text-gray-400'
                        }`}
                      >
                        <span className="font-sans text-[11px] font-bold">Moov Money</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setPaymentMethod('wave')}
                        className={`p-2 rounded-sm border text-center transition-all cursor-pointer ${
                          paymentMethod === 'wave' ? 'border-[#1E90FF] bg-[#1E90FF]/10 text-white' : 'border-gold/10 bg-rich-black/20 text-gray-400'
                        }`}
                      >
                        <span className="font-sans text-[11px] font-bold">Wave BF</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setPaymentMethod('card')}
                        className={`p-2 rounded-sm border text-center transition-all cursor-pointer ${
                          paymentMethod === 'card' ? 'border-gold bg-gold/10 text-gold' : 'border-gold/10 bg-rich-black/20 text-gray-400'
                        }`}
                      >
                        <span className="font-sans text-[11px] font-bold">Prestige Card</span>
                      </button>
                    </div>

                    {paymentMethod !== 'card' && (
                      <div className="flex flex-col">
                        <label className="text-[10px] uppercase tracking-wider text-gray-400 font-mono mb-1">
                          Numéro Mobile Money (+226 obligatoire) *
                        </label>
                        <input 
                          type="tel" 
                          required
                          value={phoneNumber}
                          onChange={(e) => setPhoneNumber(e.target.value)}
                          placeholder="Ex: +226 72 36 64 84"
                          className="px-3 py-2.5 bg-rich-black border border-gold/15 text-white placeholder-gray-600 focus:outline-none focus:border-gold transition-colors text-xs rounded-sm"
                        />
                      </div>
                    )}
                  </div>

                  {/* Submit Button */}
                  <div className="pt-4 flex items-center justify-between border-t border-gold/15">
                    <div className="text-left">
                      <span className="text-[10px] font-mono text-gray-500 uppercase block leading-none">MONTANT ROYAL</span>
                      <span className="text-xl font-display text-white font-bold">{getTierInfo().amount.toLocaleString()} FCFA</span>
                    </div>
                    <button
                      type="submit"
                      className="px-6 py-3 bg-gold hover:bg-gold-hover text-rich-black text-xs uppercase tracking-widest font-bold rounded-sm transition-all cursor-pointer"
                    >
                      Procéder au Paiement
                    </button>
                  </div>

                </form>
              )}

              {/* STAGE SIMULATOR */}
              {paymentStep === 'simulation' && (
                <div className="text-center py-6 space-y-6">
                  {/* Code USSD simulation */}
                  <div className="p-6 bg-rich-black/80 rounded-sm border border-gold/20 inline-block max-w-sm mx-auto">
                    <Landmark className="w-12 h-12 text-gold mx-auto mb-4 animate-bounce" />
                    <h4 className="font-display text-lg text-white tracking-widest uppercase mb-2">Simulateur d'Audit de Paiement</h4>
                    
                    {paymentMethod !== 'card' ? (
                      <p className="text-xs text-gray-400 font-sans leading-relaxed">
                        Pour valider votre mécénat de <span className="text-gold font-bold">{getTierInfo().amount.toLocaleString()} FCFA</span> via <span className="uppercase text-white font-bold">{paymentMethod} Money</span>, veuillez composer le code USSD requis ou valider la notification Push envoyée au <span className="text-white font-medium">{phoneNumber}</span>.
                      </p>
                    ) : (
                      <p className="text-xs text-gray-400 font-sans leading-relaxed">
                        Validation sécurisée en cours de votre carte de prestige exclusive EMZ. La transaction de <span className="text-gold font-bold">{getTierInfo().amount.toLocaleString()} FCFA</span> est en cours d'approbation.
                      </p>
                    )}

                    <div className="bg-luxury-gray/80 p-3 rounded border border-gold/10 mt-4 text-left font-mono text-[11px] text-gray-300">
                      <div><span className="text-gold">Destinataire:</span> EMZ RECORD BURKINA</div>
                      <div><span className="text-gold">Nature:</span> CAGNOTTE SOLIDAIRE D'ÉLITE</div>
                      <div><span className="text-gold">Montant:</span> {getTierInfo().amount.toLocaleString()} FCFA</div>
                      <div><span className="text-gold">Statut:</span> En attente d'approbation mobile</div>
                    </div>
                  </div>

                  <div className="flex flex-col items-center gap-3">
                    <button
                      onClick={confirmPaymentSimulation}
                      disabled={isProcessing}
                      className="w-full max-w-xs py-3.5 bg-gold text-rich-black uppercase tracking-widest font-bold text-xs hover:bg-gold-hover transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                    >
                      {isProcessing ? (
                        <>
                          <Coins className="w-4 h-4 animate-spin text-rich-black" />
                          <span>Validation en cours...</span>
                        </>
                      ) : (
                        <span>Simuler l'autorisation (Confirmer)</span>
                      )}
                    </button>
                    {!isProcessing && (
                      <button
                        onClick={() => setPaymentStep('details')}
                        className="text-xs text-gray-500 hover:text-white transition-colors"
                      >
                        Retour aux coordonnées
                      </button>
                    )}
                  </div>
                </div>
              )}

              {/* SUCCESS STATE */}
              {paymentStep === 'success' && (
                <div className="text-center py-8 space-y-6">
                  <div className="w-16 h-16 bg-gold/10 rounded-full border border-gold flex items-center justify-center mx-auto text-gold">
                    <CheckCircle2 className="w-10 h-10 animate-pulse" />
                  </div>

                  <div className="space-y-2">
                    <h3 className="font-display text-2xl text-white uppercase tracking-wider">MÉCÉNAT VALIDÉ ET SCÈLÉ</h3>
                    <p className="text-xs text-gray-300 font-sans max-w-md mx-auto leading-relaxed">
                      Grand merci, honorable <span className="text-gold font-medium">{backerName}</span> ! Votre splendide contribution de <span className="text-gold font-bold">{getTierInfo().amount.toLocaleString()} FCFA</span> a été créditée au projet de l'artiste.
                    </p>
                  </div>

                  <div className="bg-rich-black/40 p-4 rounded-sm border border-gold/10 max-w-sm mx-auto text-left space-y-1.5 font-mono text-[10px] text-gray-400 uppercase">
                    <div className="text-gold font-bold">Certificat Impérial de Donateur</div>
                    <div className="w-full h-[1px] bg-gold/10 my-2" />
                    <div><span className="text-gray-600">ID TRANSACTION:</span> TXN-{Math.floor(100000 + Math.random() * 900000)}</div>
                    <div><span className="text-gray-600">DONNEUR:</span> {backerName}</div>
                    <div><span className="text-gray-600">RECOMPENSE:</span> {getTierInfo().label}</div>
                    <div><span className="text-gray-600">DATE UTC:</span> {new Date().toLocaleDateString('fr-FR')}</div>
                  </div>

                  <button
                    onClick={() => setIsModalOpen(false)}
                    className="w-full max-w-xs py-3 bg-gold text-rich-black hover:bg-gold-hover uppercase text-xs tracking-widest font-bold font-sans rounded-sm transition-all cursor-pointer"
                  >
                    Fermer le Mécénat
                  </button>
                </div>
              )}

            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}
