import { motion } from 'motion/react';
import { Sliders, Mic, Activity, Radio, Quote, Disc } from 'lucide-react';
import { SERVICES } from '../data';
import kosaPicImage from '../assets/images/regenerated_image_1780847961200.jpg';

export default function Studio() {
  // Map icons dynamically
  const getIcon = (id: string) => {
    switch (id) {
      case 'serv-1':
        return <Sliders className="w-8 h-8 text-gold" />;
      case 'serv-2':
        return <Mic className="w-8 h-8 text-gold" />;
      case 'serv-3':
        return <Activity className="w-8 h-8 text-gold" />;
      case 'serv-4':
        return <Radio className="w-8 h-8 text-gold" />;
      default:
        return <Sliders className="w-8 h-8 text-gold" />;
    }
  };

  return (
    <section id="studio" className="py-24 bg-rich-black relative">
      <div className="absolute top-0 left-0 w-[400px] h-[450px] bg-gold/5 blur-[120px] rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6">
        
        {/* Section Header */}
        <div className="mb-16 border-b border-gold/10 pb-8 flex flex-col md:flex-row md:items-end justify-between">
          <div>
            <span className="text-xs uppercase tracking-[0.3em] text-gold font-sans font-medium block mb-2">
              Ingénierie & Direction Acoustique
            </span>
            <h2 className="font-display text-5xl md:text-6xl tracking-wide uppercase text-white">
              Studio & <span className="gold-gradient-text font-light">Services</span>
            </h2>
          </div>
          <div className="text-gray-400 font-sans font-light max-w-sm text-sm mt-4 md:mt-0">
            Un complexe d'enregistrement légendaire équipé de technologies analogiques et numériques d'élite internationale.
          </div>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-24">
          {SERVICES.map((service, idx) => (
            <motion.div
              key={service.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: idx * 0.1 }}
              className="glass-card p-8 rounded-sm hover:border-gold/40 transition-all duration-300 group flex flex-col justify-between h-[250px]"
            >
              <div>
                <div className="mb-6 p-3 bg-gold/5 border border-gold/15 w-fit rounded-sm group-hover:bg-gold/10 group-hover:border-gold/30 transition-colors">
                  {getIcon(service.id)}
                </div>
                <h3 className="font-sans font-medium text-lg text-white mb-2 group-hover:text-gold transition-colors">
                  {service.title}
                </h3>
              </div>
              <p className="text-gray-400 font-sans font-light text-xs leading-relaxed">
                {service.description}
              </p>
            </motion.div>
          ))}
        </div>

        {/* KOSA PIC Spotlight - Elegant Luxury Bio layout */}
        <div className="relative border border-gold/20 bg-gradient-to-tr from-luxury-gray/90 to-[#121212] p-8 md:p-16 rounded-sm max-w-5xl mx-auto overflow-hidden shadow-2xl">
          {/* Subtle background disc */}
          <div className="absolute -right-20 -bottom-20 opacity-5 pointer-events-none">
            <Disc className="w-80 h-80 text-gold animate-[spin_20s_linear_infinite]" />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center relative z-10">
            {/* Left Block: Image */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="lg:col-span-5 relative group"
            >
              <div className="relative aspect-[4/5] rounded-sm overflow-hidden border border-gold/20 shadow-lg">
                <img
                  src={kosaPicImage}
                  alt="KOSA PIC en session Studio"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover filter grayscale group-hover:grayscale-0 transition-all duration-700"
                />
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-rich-black/95 to-transparent p-6 text-center">
                  <span className="text-xs uppercase tracking-[0.25em] text-white">
                    The Voice of Gold
                  </span>
                </div>
              </div>
            </motion.div>

            {/* Right Block: Content & Quotes */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="lg:col-span-7 flex flex-col justify-center"
            >
              <div className="mb-6">
                <Quote className="w-10 h-10 text-gold/30 mb-2" />
                <span className="text-xs tracking-widest text-[#C9A84C] font-mono uppercase block mb-1">
                  En vedette — L'Artiste Étoile
                </span>
                <h3 className="font-display text-4xl sm:text-5xl text-white tracking-wide uppercase leading-none">
                  KOSA PIC
                </h3>
              </div>

              {/* Bio block with exquisite typography */}
              <blockquote className="text-xl font-sans font-light italic text-[#E8E8E8] leading-relaxed mb-6 border-l-2 border-gold/50 pl-6">
                "La musique de prestige est une élévation de l'âme. Chaque note, chaque parole posée sur le beat doit résonner avec l'héritage majestueux de l'Afrique pour conquérir le monde entier."
              </blockquote>

              <p className="text-gray-400 font-sans font-light text-sm leading-relaxed mb-8">
                Icône incontestée de la chanson de luxe d'Afrique, KOSA PIC marie l'énergie afro-pop moderne à des nuances lyriques riches et profondes. Son timbre captivant et sa capacité à émouvoir au premier couplet font de lui l'ambassadeur ultime du prestige d'EMZ RECORD, incarnant le son raffiné qui s'exporte au-delà des océans.
              </p>

              {/* Decorative signature & title */}
              <div className="flex items-center gap-4">
                <div className="w-8 h-[1px] bg-gold" />
                <div>
                  <h4 className="font-sans font-semibold text-white tracking-widest text-xs uppercase">
                    KOSA PIC
                  </h4>
                  <span className="text-gray-500 font-mono text-[10px] uppercase">
                    Chanteur Phare & Interprète d'Élite
                  </span>
                </div>
              </div>
            </motion.div>
          </div>
        </div>


      </div>
    </section>
  );
}
