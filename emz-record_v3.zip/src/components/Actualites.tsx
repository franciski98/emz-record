import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Calendar, ArrowUpRight, X, Clock, MapPin, Feather } from 'lucide-react';
import { NEWS } from '../data';
import { NewsStory } from '../types';

export default function Actualites() {
  const [selectedNews, setSelectedNews] = useState<NewsStory | null>(null);

  return (
    <section id="news" className="py-24 bg-rich-black relative">
      <div className="absolute top-0 right-1/4 w-[250px] h-[250px] bg-gold/5 blur-[100px] rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6">
        
        {/* Section Header */}
        <div className="mb-16 flex flex-col md:flex-row md:items-end justify-between gap-6 border-b border-gold/10 pb-8">
          <div>
            <span className="text-xs uppercase tracking-[0.3em] text-gold font-sans font-medium block mb-2">
              Le Carnet de EMZ RECORD
            </span>
            <h2 className="font-display text-5xl md:text-6xl tracking-wide uppercase text-white">
              La Gazette <span className="gold-gradient-text font-light">de l'Élite</span>
            </h2>
          </div>
          <div className="text-right max-w-sm">
            <p className="text-xs text-gray-500 font-mono italic">
              — Chroniques régulières de notre ascension et de l'excellence culturelle de notre prestigieux roster.
            </p>
          </div>
        </div>

        {/* Luxury Newspaper Journal-Style Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 divide-y md:divide-y-0 md:divide-x divide-gold/15">
          {NEWS.map((story, idx) => (
            <motion.article
              key={story.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: idx * 0.15 }}
              className={`flex flex-col h-full group cursor-pointer ${
                idx > 0 ? 'pt-8 md:pt-0 md:pl-8' : 'md:pr-2'
              }`}
              onClick={() => setSelectedNews(story)}
            >
              {/* Image Preview Container */}
              <div className="relative aspect-[4/3] w-full mb-6 overflow-hidden rounded-sm filter grayscale group-hover:grayscale-0 transition-all duration-500 border border-gold/10 group-hover:border-gold/30">
                <img
                  src={story.image}
                  alt={story.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute top-4 left-4">
                  <span className="text-[10px] tracking-widest font-sans font-bold bg-gold text-rich-black px-3 py-1 shadow-sm uppercase">
                    {story.badge}
                  </span>
                </div>
              </div>

              {/* Date Metadata */}
              <div className="flex items-center gap-2 mb-3 text-gray-500 font-mono text-xs">
                <Calendar className="w-3.5 h-3.5 text-gold" />
                <span>{story.date}</span>
              </div>

              {/* Title & Chevron */}
              <h3 className="font-sans font-medium text-xl leading-snug text-white group-hover:text-gold transition-colors mb-4 line-clamp-2">
                {story.title}
              </h3>

              {/* Summary */}
              <p className="text-gray-400 font-sans font-light text-sm leading-relaxed mb-6 line-clamp-3">
                {story.summary}
              </p>

              {/* Editorial Footer Trigger */}
              <div className="mt-auto flex items-center gap-1.5 text-xs tracking-widest font-sans font-bold text-gold uppercase group-hover:text-gold-hover transition-colors">
                <span>Lire la Chronique</span>
                <ArrowUpRight className="w-3.5 h-3.5 transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
              </div>
            </motion.article>
          ))}
        </div>

        {/* Luxury Newspaper Inner Accent Border */}
        <div className="border-t border-b border-gold/10 py-4 mt-16 text-center text-xs tracking-widest font-sans text-gold/60 uppercase">
          ✦   EMZ RECORD — GAGE DE PRESTIGE ET D'EXCELLENCE SONORE MONDIALE   ✦
        </div>

      </div>

      {/* Luxury Read Drawer Overlay (Modal) */}
      <AnimatePresence>
        {selectedNews && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-rich-black/90 backdrop-blur-md">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              transition={{ duration: 0.4 }}
              className="relative w-full max-w-3xl max-h-[90vh] overflow-y-auto glass-card border border-gold/30 p-8 md:p-12 rounded-sm"
            >
              <button
                onClick={() => setSelectedNews(null)}
                className="absolute top-6 right-6 text-gray-400 hover:text-gold transition-colors p-2"
                aria-label="Fermer"
              >
                <X className="w-6 h-6" />
              </button>

              {/* Badge & Meta info */}
              <div className="flex flex-wrap items-center gap-4 mb-6 pt-4 text-xs font-mono text-gray-400 border-b border-gold/10 pb-4">
                <span className="bg-gold text-rich-black px-3 py-1 font-sans font-bold uppercase tracking-wider">
                  {selectedNews.badge}
                </span>
                <div className="flex items-center gap-1 text-gold">
                  <Calendar className="w-3.5 h-3.5" />
                  <span>{selectedNews.date}</span>
                </div>
                <div className="flex items-center gap-1 text-gray-500">
                  <Clock className="w-3.5 h-3.5" />
                  <span>3 min de lecture</span>
                </div>
              </div>

              {/* Modal Image Header */}
              <div className="aspect-video w-full overflow-hidden mb-8 border border-gold/10 rounded-sm">
                <img
                  src={selectedNews.image}
                  alt={selectedNews.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Main Modal Title */}
              <h2 className="font-sans font-medium text-2xl md:text-3xl lg:text-4xl text-white mb-6 leading-tight">
                {selectedNews.title}
              </h2>

              {/* Lead summary */}
              <p className="text-gold font-sans font-light italic text-base md:text-lg mb-8 leading-relaxed border-l-2 border-gold pl-4 bg-gold/5 py-2">
                {selectedNews.summary}
              </p>

              {/* Main Body text with luxurious formatting */}
              <div className="text-gray-300 font-sans font-light leading-relaxed text-sm md:text-base space-y-6">
                <p>{selectedNews.content}</p>
                <p>
                  Ce projet d'envergure témoigne de la rigueur dont fait preuve le label EMZ RECORD. 
                  En conjuguant techniques de pointe et préservation du patrimoine de la musique 
                  africaine, l'équipe menée par Marez pose ainsi des bases inébranlables pour les 
                  générations futures d'artistes à venir. 
                </p>
                <p className="pt-4 text-xs font-serif italic text-gold flex items-center gap-2">
                  <Feather className="w-4 h-4" />
                  — Rédactrice en Chef, Les Carnets de l'Élite
                </p>
              </div>

              {/* Footer Close Button */}
              <div className="mt-12 pt-8 border-t border-gold/10 flex justify-end">
                <button
                  onClick={() => setSelectedNews(null)}
                  className="px-6 py-2 border border-gold/40 text-gold hover:bg-gold hover:text-rich-black transition-all text-xs tracking-widest uppercase font-sans"
                >
                  Fermer la Gazette
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}
