import Logo from './Logo';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-rich-black border-t border-gold/10 py-16 px-6">
      <div className="max-w-4xl mx-auto flex flex-col items-center text-center">
        
        {/* Branding Emblem matching official claws logo */}
        <div className="flex flex-col items-center mb-6 group cursor-pointer transition-transform duration-300 hover:scale-105">
          <Logo iconOnly={true} color="gold" showText={false} className="w-12 h-10 text-gold mb-2" />
          <span className="font-display text-xl tracking-widest text-[#FFEAB5] uppercase mt-1">
            EMZ RECORD
          </span>
        </div>

        {/* Short Statement */}
        <p className="text-gray-500 font-sans font-light text-xs max-w-md leading-relaxed mb-8">
          Maison de production, d'édition et de direction artistique sélective. Redéfinir l'excellence sonore à l'échelle panafricaine et mondiale.
        </p>

        {/* Social Icons */}
        <div className="flex gap-6 mb-8 text-gray-500">
          <a href="https://instagram.com" className="hover:text-gold transition-colors text-xs uppercase tracking-widest font-sans">Instagram</a>
          <span className="text-gold/20">•</span>
          <a href="https://youtube.com" className="hover:text-gold transition-colors text-xs uppercase tracking-widest font-sans">YouTube</a>
          <span className="text-gold/20">•</span>
          <a href="https://spotify.com" className="hover:text-gold transition-colors text-xs uppercase tracking-widest font-sans">Spotify</a>
          <span className="text-gold/20">•</span>
          <a href="https://soundcloud.com" className="hover:text-gold transition-colors text-xs uppercase tracking-widest font-sans">SoundCloud</a>
        </div>

        {/* Copyright Details */}
        <div className="text-gray-600 font-mono text-[10px] uppercase tracking-wider">
          © {currentYear} EMZ RECORD Elite Experience. Tous droits réservés.
        </div>
        
      </div>
    </footer>
  );
}
