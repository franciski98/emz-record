import { Artist, NewsStory, StudioService, BoutiqueItem } from './types';
import kosaPicImage from './assets/images/regenerated_image_1780847960200.jpg';
import flowmanBoyImage from './assets/images/regenerated_image_1780851355097.jpg';
import welerGangImage from './assets/images/regenerated_image_1780851519428.jpg';
import djoLeRapideImage from './assets/images/regenerated_image_1780851520352.jpg';
import hugoBossImage from './assets/images/regenerated_image_1780851521583.jpg';
import cheezyBossImage from './assets/images/regenerated_image_1780851522427.jpg';
import elBanditaImage from './assets/images/el_bandita_portrait_1786895269215.jpg';
import salbyImage from './assets/images/salby_portrait_1786895256120.jpg';
import josbyImage from './assets/images/josby_portrait_1786895282380.jpg';
import limaImage from './assets/images/lima_portrait_1786895301333.jpg';

export const FEATURED_RELEASE = {
  title: "VIBRATIONS D'OR",
  artist: "KOSA PIC & AUDIA THE MANY",
  releaseDate: "01 Juin 2026",
  youtubeId: "c4VyGSavDao", // The new legendary release by KOSA PIC
  description: "L'apogée de l'Afro-fusion de luxe. Une symphonie de basses chaudes, de rythmes envoûtants et de voix célestes, sublimée par les performances envoûtantes du chanteur étoile KOSA PIC et de la diva Audia The Many.",
  streamingLinks: {
    spotify: "https://spotify.com",
    appleMusic: "https://apple.com",
    youtube: "https://www.youtube.com/watch?v=c4VyGSavDao&list=RDc4VyGSavDao&start_radio=1"
  }
};

export const ROSTER: Artist[] = [
  {
    id: "kosa-pic",
    name: "KOSA PIC",
    role: "Chanteur Vedette & Icône Afro-Pop",
    image: kosaPicImage,
    bio: "L'étoile scintillante de la chanson moderne de luxe africaine. Chanteur vedette et visage phare d'EMZ RECORD, KOSA PIC séduit par sa voix céleste de velours et ses vêtements d'une originalité de prestige, inspirant une véritable signature de haute couture panafricaine.",
    streamingLinks: {
      spotify: "https://spotify.com",
      appleMusic: "https://apple.com",
      youtube: "https://www.youtube.com/watch?v=c4VyGSavDao",
      instagram: "https://instagram.com"
    }
  },
  {
    id: "flowman-boy",
    name: "FLOWMAN BOY",
    role: "Maître de l'Afro-Vibe & Mélodiste",
    image: flowmanBoyImage,
    bio: "Le virtuose du groove et des mélodies entêtantes. FLOWMAN BOY fusionne des rythmes traditionnels fascinants avec des envolées contemporaines pour un rendu sonore d'une richesse absolue.",
    streamingLinks: {
      spotify: "https://spotify.com",
      appleMusic: "https://apple.com",
      youtube: "https://youtube.com",
      instagram: "https://instagram.com"
    }
  },
  {
    id: "salby",
    name: "SALBY",
    role: "Prodige de l'Afro-Pop & Flow Solaire",
    image: salbyImage,
    bio: "L'énergie solaire et le charisme éclatant d'EMZ RECORD. SALBY illumine la scène musicale avec ses refrains d'or entraînants, son sourire communicatif et son flow fédérateur qui soulève les foules de Ouagadougou à toute l'Afrique.",
    streamingLinks: {
      spotify: "https://spotify.com",
      appleMusic: "https://apple.com",
      youtube: "https://youtube.com",
      instagram: "https://instagram.com"
    }
  },
  {
    id: "el-bandita",
    name: "EL BANDITA",
    role: "Icône Afro-Street & Révolutionnaire du Style",
    image: elBanditaImage,
    bio: "L'esprit libre et le charisme indomptable. EL BANDITA impose une signature visuelle et musicale audacieuse, mariant l'authenticité de la rue noble, le Faso Danfani stylisé et des rimes incisives gravées dans l'or.",
    streamingLinks: {
      spotify: "https://spotify.com",
      appleMusic: "https://apple.com",
      youtube: "https://youtube.com",
      instagram: "https://instagram.com"
    }
  },
  {
    id: "josby",
    name: "JOSBY",
    role: "Virtuose Trap & Étoile Nouvelle Vague",
    image: josbyImage,
    bio: "La fougue créative et le style percutant de la nouvelle génération. JOSBY embrase la scène avec son énergie brute au bandana rouge, ses hooks électrisants et ses productions modernes ultra-rythmées.",
    streamingLinks: {
      spotify: "https://spotify.com",
      appleMusic: "https://apple.com",
      youtube: "https://youtube.com",
      instagram: "https://instagram.com"
    }
  },
  {
    id: "lima",
    name: "LIMA",
    role: "Diva de la Scène Urbaine & Live Queen",
    image: limaImage,
    bio: "La puissance vocale souveraine et la reine incontestée des grands concerts en stade. LIMA captive par sa présence scénique magistrale, son style streetwear d'apparat et ses envolées vocales envoûtantes.",
    streamingLinks: {
      spotify: "https://spotify.com",
      appleMusic: "https://apple.com",
      youtube: "https://youtube.com",
      instagram: "https://instagram.com"
    }
  },
  {
    id: "weler-gang",
    name: "WELER GANG",
    role: "Collectif Afro-Fusion & Rap d'Élite",
    image: welerGangImage,
    bio: "Le collectif révolutionnaire d'EMZ Record. WELER GANG bouscule les codes musicaux avec une énergie collective inégalée, mêlant flows incisifs et refrains majestueux à la résonance universelle.",
    streamingLinks: {
      spotify: "https://spotify.com",
      appleMusic: "https://apple.com",
      youtube: "https://youtube.com",
      instagram: "https://instagram.com"
    }
  },
  {
    id: "djo-le-rapide",
    name: "DJO LE RAPIDE",
    role: "Lyriciste d'Élite & Virtuose du Flow",
    image: djoLeRapideImage,
    bio: "Des rimes gravées dans l'or. DJO LE RAPIDE impressionne par son débit foudroyant, la précision de sa plume poétique et son charisme souverain qui domine les scènes.",
    streamingLinks: {
      spotify: "https://spotify.com",
      appleMusic: "https://apple.com",
      youtube: "https://youtube.com",
      instagram: "https://instagram.com"
    }
  },
  {
    id: "hugo-boss",
    name: "HUGO BOSS",
    role: "Leader de l'Afrobeats de Prestige",
    image: hugoBossImage,
    bio: "L'autorité du rythme lourd et de l'ambiance royale. HUGO BOSS produit des ondes monumentales mêlant de riches textures électroniques à des percussions majestueuses d'Afrique.",
    streamingLinks: {
      spotify: "https://spotify.com",
      appleMusic: "https://apple.com",
      youtube: "https://youtube.com",
      instagram: "https://instagram.com"
    }
  },
  {
    id: "cheezy-boss",
    name: "CHEEZY BOSS",
    role: "Producteur-Interprète & Hitmaker",
    image: cheezyBossImage,
    bio: "L'alchimiste d'EMZ RECORD. Concepteur de sonorités cultes, CHEEZY BOSS insère un grain d'audace irrésistible et des arrangements d'un raffinement souverain.",
    streamingLinks: {
      spotify: "https://spotify.com",
      appleMusic: "https://apple.com",
      youtube: "https://youtube.com",
      instagram: "https://instagram.com"
    }
  }
];

export const NEWS: NewsStory[] = [
  {
    id: "1",
    title: "Le concert privé de lancement à l'Hôtel de la Paix",
    summary: "Une soirée exclusive réunissant l'élite culturelle et politique pour célébrer le nouveau sommet sonore du label.",
    content: "Dans un décor orné d'or brossé et d'écrans de velours, EMZ RECORD a dévoilé son roster devant un parterre d'invités prestigieux. Un live mémorable orchestré par KOSA PIC qui a suspendu le temps.",
    date: "04 Juin 2026",
    badge: "EXCLUSIVITÉ",
    image: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "2",
    title: "Certifié Disque d'Or pour l'album 'SOUVERAIN'",
    summary: "L'album de FLOWMAN BOY franchit le cap historique de l'excellence commerciale et critique.",
    content: "Moins de trois mois après sa sortie, l'album de FLOWMAN BOY, entièrement porté par les mélodies et la direction artistique prestigieuse d'EMZ RECORD, est certifié Or. Ce chef-d'œuvre installe définitivement le label comme le nouveau standard du luxe musical.",
    date: "28 Mai 2026",
    badge: "DISTINCTION",
    image: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "3",
    title: "Inauguration du nouveau Studio EMZ 'Aura Or'",
    summary: "Une prouesse de design acoustique équipée de l'équipement légendaire SSL et d'un traitement sonore premium.",
    content: "Offrant une vue panoramique et un intérieur habillé d'acajou noir et d'or brossé, le nouveau complexe d'enregistrement accueille désormais des sessions d'écriture pour les plus grands artistes mondiaux de passage.",
    date: "15 Mai 2026",
    badge: "STUDIO",
    image: "https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?auto=format&fit=crop&q=80&w=600"
  }
];

export const SERVICES: StudioService[] = [
  {
    id: "serv-1",
    title: "Direction Artistique & Production",
    description: "Conception de projets musicaux sur-mesure de l'identité sonore au mixage final de prestige sous la direction de notre équipe d'experts."
  },
  {
    id: "serv-2",
    title: "Enregistrement & Acoustique 'Aura Or'",
    description: "Une cabine de haut vol isolée de manière chirurgicale, avec des micros vintage rares (Neumann U87, Telefunken) et des préamplis haut de gamme."
  },
  {
    id: "serv-3",
    title: "Mastering Analogique Haute Fidélité",
    description: "La touche finale qui donne à vos titres cette brillance dorée, cette profondeur de basses et ce volume requis pour les scènes d'élite internationale."
  },
  {
    id: "serv-4",
    title: "Publishing & Partenariats de Prestige",
    description: "Placement de vos titres auprès de marques de luxe, de grands réalisateurs cinématographiques et distribution via des canaux ultra-sélectifs."
  }
];

export const BOUTIQUE_ITEMS: BoutiqueItem[] = [
  {
    id: "prod-cap",
    title: "Casquette Bleue Velours 'KOSA ELITE'",
    price: "75 000 FCFA",
    category: "Accessoires Couture",
    artistCreator: "KOSA PIC",
    image: "https://images.unsplash.com/photo-1588850561407-ed78c282e89b?auto=format&fit=crop&q=80&w=600",
    description: "La célèbre casquette bleu roi portée par KOSA PIC. Façonnée dans un velours d'Italie précieux et brodée à la main de l'effigie claw d'or d'EMZ.",
    details: [
      "Velours de coton d'Italie haut grade",
      "Claws d'EMZ brodées au fil d'or fin",
      "Édition ultra-limitée (50 pièces numérotées)",
      "Vendu avec son coffret en cuir de prestige et carte d'authenticité signée"
    ]
  },
  {
    id: "prod-veste",
    title: "Blouson Bomber 'Chessboard Silver'",
    price: "250 000 FCFA",
    category: "Prêt-à-Porter Haute Couture",
    artistCreator: "KOSA PIC",
    image: "https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&q=80&w=600",
    description: "Inspiré par le blouson damier chromé de Kosa Pic. Alliant élégance futuriste, drapé satiné et zips étincelants d'un raffinement souverain.",
    details: [
      "Jacquard métallique argenté et soyeux",
      "Manchettes et bord-côtes ajustés ultra-soft",
      "Zips robustes polis en or brossé",
      "Doublure royale en satin bordeaux respirant"
    ]
  },
  {
    id: "prod-kimono",
    title: "Robe Kimono en Satin 'Souverain d'Or'",
    price: "320 000 FCFA",
    category: "Robes d'Apparat",
    artistCreator: "AUDIA THE MANY",
    image: "https://images.unsplash.com/photo-1595777457583-95e059d581b8?auto=format&fit=crop&q=80&w=600",
    description: "Inspiré par la divine présence d'Audia The Many. Ce kimono fluide drape le corps d'une soie dorée sensationnelle ornée de motifs ciselés de kora traditionnelle.",
    details: [
      "100% Crêpe de Soie et Satin lourd premium",
      "Motifs kora brodés en fils métalliques dorés 24k",
      "Coupe majestueuse drapée à l'épaule",
      "Housse de transport de luxe en lin naturel embossé d'or"
    ]
  },
  {
    id: "prod-josby-jacket",
    title: "Blouson Cuir Écarlate 'JOSBY FLAME'",
    price: "280 000 FCFA",
    category: "Prêt-à-Porter Haute Couture",
    artistCreator: "JOSBY",
    image: "https://images.unsplash.com/photo-1521223890158-f9f7c3d5d504?auto=format&fit=crop&q=80&w=600",
    description: "Le mythique blouson motard en cuir nappa rouge vif de JOSBY, agrémenté de boutons-pression plaqués or et d'un bandana de soie rouge assorti.",
    details: [
      "Cuir nappa d'agneau souple sélectionné à la main",
      "Boutons de pression ciselés or 24k",
      "Fourni avec le bandana en soie naturelle d'Italie",
      "Doublure intérieure noire soyeuse anti-transpirante"
    ]
  },
  {
    id: "prod-elbandita-vest",
    title: "Gilet Royal Tissé 'BANDITA NOBLE'",
    price: "195 000 FCFA",
    category: "Prêt-à-Porter Haute Couture",
    artistCreator: "EL BANDITA",
    image: "https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&q=80&w=600",
    description: "Pièce haute couture confectionnée à partir d'un Faso Danfani d'exception aux motifs ondulés or et sable, signature d'El Bandita.",
    details: [
      "Faso Danfani tissé main à Bobo-Dioulasso",
      "Fil de chaîne doré résistant et doux",
      "Coupe sans manches ajustée d'apparat",
      "Poche gousset intérieure discrète"
    ]
  },
  {
    id: "prod-lima-tactical",
    title: "Veste Scénique 'LIMA QUEEN STAGE'",
    price: "310 000 FCFA",
    category: "Robes d'Apparat",
    artistCreator: "LIMA",
    image: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&q=80&w=600",
    description: "La veste tactique de scène exclusive portée par LIMA lors de ses performances en stade, fusionnant streetwear d'avant-garde et haute couture.",
    details: [
      "Gabardine technique waterproof et respirante",
      "Sangles et harnais brodés aux initiales EMZ",
      "Fermetures magnétiques dissimulées de précision",
      "Livrée dans son écrin de conservation hermétique"
    ]
  },
  {
    id: "prod-salby-jersey",
    title: "Maillot d'Honneur 'SALBY GOLD S.F.C'",
    price: "85 000 FCFA",
    category: "Accessoires Couture",
    artistCreator: "SALBY",
    image: "https://images.unsplash.com/photo-1577223625816-7546f13df25d?auto=format&fit=crop&q=80&w=600",
    description: "Le maillot blanc éclatant rehaussé de liserés dorés et du blason d'honneur brodé au fil d'or fin de SALBY.",
    details: [
      "Tissu technique haute respirabilité effet satiné",
      "Écusson d'honneur thermo-soudé en or brossé",
      "Signature manuscrite brodée au bas du vêtement",
      "Édition limitée spéciale tournée nationale"
    ]
  }
];
